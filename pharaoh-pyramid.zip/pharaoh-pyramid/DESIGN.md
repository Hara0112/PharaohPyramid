# DESIGN – Pharaoh's Pyramid (kiến trúc, vòng lặp, cân bằng, mạng & voice)

Game hài hước góc nhìn thứ nhất: bạn xuyên không thành Pharaoh, xây **kim tự tháp 26 tầng – 23.426 viên** (tầng đáy 51×51 = 2.601 viên) từ bùn bờ sông.
Công thức hình học: cạnh tầng t = 51 − 2(t−1) ⇒ tổng = 26·51·53/3 = 23.426 (được kiểm thử tự động trong `tests/test_config.mjs`).

## 1. Vòng lặp lõi (Core Loop)

```
 Múc bùn (bãi 6,7 kg)  →  Đổ vào khuôn (400 g/viên)  →  SẤY (20 s; thổi gió / quạt / nắng rút ngắn)
      ▲                                                          │
      │                                              Lấy gạch (hoặc Thùng tự thu / Băng chuyền)
  Nâng cấp ← Xu + thưởng mốc ← Đặt gạch vào ô sáng ← Vác gạch lên bậc kim tự tháp (sức mạnh = số viên mang)
      │
  Tập gym: Tạ → Sức mạnh (mang nhiều hơn) • Máy chạy bộ → Tốc độ (phi lý, có văng máy hài hước)
  Tự động hóa: Máng trộn (rót khuôn) → Giá khuôn 4/8 → Thùng thu → Băng chuyền → Xe đẩy tự động đặt gạch
```

## 2. Vòng lặp cạnh tranh (Competitive Loop)

```
 Sảnh phòng (chủ phòng chọn: Chung 1 kim tự tháp | Mỗi người 1 làn; mục tiêu 300/2.601/23.426; x EXP; x sấy; phá trò; hỗ trợ)
   → Bắt đầu → Đua (bảng xếp hạng + nguồn tin trực tiếp + voice) → Ai đạt mục tiêu / hoàn thành → Bục vinh quang + giải thưởng
   → Chơi lại (giữ phòng & kênh voice)
```
- **Chung 1 kim tự tháp**: chủ phòng là trọng tài tổng gạch; mọi người đặt vào cùng một dãy ô; xếp hạng theo **đóng góp**; "đòn kết liễu" là người đặt viên cuối.
- **Mỗi người 1 làn**: mỗi người một kim tự tháp (cách nhau 80 m) cùng luật; làn người khác hiển thị dạng tầng khối cập nhật theo tiến độ.
- **Hỗ trợ người đi sau** (chỉ làn riêng): cách người dẫn đầu >5% mục tiêu → +12% EXP/sấy; >10% → +25%.
- **Phá trò** (chủ phòng bật): ném bùn làm đối thủ chậm 40% trong 4 s + màn hình dính bùn, hồi 20 s.

## 3. Thế giới
| Khu | Vị trí | Chức năng |
|---|---|---|
| Công trường kim tự tháp | z = 0 (làn x cách 80 m) | ô đặt gạch phát sáng (24 ô kế tiếp), leo từng bậc 0,5 m |
| Khu tài nguyên | z ≈ 73–100 | 11 bãi bùn (6,7 kg, hồi 0,25 kg/s), sông, cọ, đá |
| Trung tâm Nâng cấp (obelisk) | (0, 46) | nâng cấp đội (quỹ chung), cá nhân, bản thiết kế |
| Desert Gym | (0, −72) | 3 giá tạ + 3 máy chạy bộ |

## 4. Cân bằng (sinh tự động từ `config.js` bằng `node tests/gen_tables.mjs`)

### Sức mạnh (tạ)

| Lv | Mang (viên) | Tải (kg) | EXP lên cấp |
|---|---|---|---|
| 1 | 1 | 2.5 | 30 |
| 2 | 1 | 2.5 | 37 |
| 5 | 4 | 10 | 66 |
| 10 | 8 | 20 | 180 |
| 12 | 9 | 22.5 | 267 |
| 20 | 15 | 37.5 | 1,312 |
| 30 | 23 | 57.5 | 9,584 |
| 40 | 31 | 77.5 | 70,009 |
| 50 | 39 | 97.5 | 511,391 |
| 60 | 47 | 117.5 | 3,735,522 |

### Tốc độ (máy chạy bộ)

| Lv | m/s | km/h | EXP lên cấp |
|---|---|---|---|
| 1 | 6 | 22 | 30 |
| 5 | 8.78 | 32 | 66 |
| 10 | 13.34 | 48 | 180 |
| 20 | 26.06 | 94 | 1,312 |
| 30 | 43.58 | 157 | 9,584 |
| 40 | 65.9 | 237 | 70,009 |
| 50 | 93.02 | 335 | 511,391 |
| 60 | 124.94 | 450 | 3,735,522 |
| 80 | 140 | 504 | 199,318,623 |

### 26 tầng kim tự tháp

| Tầng | Cạnh | Viên | Cộng dồn | Xu/viên |
|---|---|---|---|---|
| 1 | 51×51 | 2,601 | 2,601 | 2 |
| 2 | 49×49 | 2,401 | 5,002 | 2 |
| 3 | 47×47 | 2,209 | 7,211 | 3 |
| 4 | 45×45 | 2,025 | 9,236 | 3 |
| 5 | 43×43 | 1,849 | 11,085 | 3 |
| 6 | 41×41 | 1,681 | 12,766 | 4 |
| 7 | 39×39 | 1,521 | 14,287 | 4 |
| 8 | 37×37 | 1,369 | 15,656 | 4 |
| 9 | 35×35 | 1,225 | 16,881 | 5 |
| 10 | 33×33 | 1,089 | 17,970 | 6 |
| 11 | 31×31 | 961 | 18,931 | 6 |
| 12 | 29×29 | 841 | 19,772 | 7 |
| 13 | 27×27 | 729 | 20,501 | 8 |
| 14 | 25×25 | 625 | 21,126 | 9 |
| 15 | 23×23 | 529 | 21,655 | 10 |
| 16 | 21×21 | 441 | 22,096 | 11 |
| 17 | 19×19 | 361 | 22,457 | 12 |
| 18 | 17×17 | 289 | 22,746 | 14 |
| 19 | 15×15 | 225 | 22,971 | 15 |
| 20 | 13×13 | 169 | 23,140 | 17 |
| 21 | 11×11 | 121 | 23,261 | 19 |
| 22 | 9×9 | 81 | 23,342 | 22 |
| 23 | 7×7 | 49 | 23,391 | 24 |
| 24 | 5×5 | 25 | 23,416 | 27 |
| 25 | 3×3 | 9 | 23,425 | 30 |
| 26 | 1×1 | 1 | 23,426 | 34 |

### Tốc độ sấy & sản lượng lý thuyết mỗi giá khuôn (chưa tính di chuyển)

| Cấu hình | Hệ số sấy | Thời gian sấy | Viên/phút/giá |
|---|---|---|---|
| Khuôn đơn, không hỗ trợ | x1.00 | 20.0 s | 3.0 |
| Khuôn đơn + thổi gió | x2.00 | 10.0 s | 6.0 |
| Giá 4 + 1 quạt + nắng 20% | x1.60 | 12.5 s | 19.2 |
| Giá 8 + 2 quạt + nắng 60% | x2.28 | 8.8 s | 54.7 |
| Giá 8 + 3 quạt + nắng 60% + EXP/đua x2 sấy | x4.95 | 4.0 s | 118.8 |

### Mốc & mở khoá

| Viên | Thưởng | Mở khoá |
|---|---|---|
| 25 | +40 xu | Xô gỗ, Quạt sấy |
| 50 | +80 xu | Thùng gạch tự thu |
| 100 | +120 xu | Giá 4 khuôn |
| 175 | +160 xu | Phễu 20 kg, Băng chuyền |
| 300 | +220 xu | Máng trộn bùn |
| 500 | +300 xu | Giá 8 khuôn |
| 1,000 | +500 xu | Xe đẩy tự động |
| 2,601 | +1000 xu | Hoàn thành TẦNG ĐÁY! |

### Giá công trình

| Công trình | Giá (xu) | Mở khoá ở (viên) |
|---|---|---|
| Khuôn gạch (400 g) | 30 | 0 |
| Giá 4 khuôn | 250 | 100 |
| Giá 8 khuôn | 900 | 500 |
| Quạt sấy (+40% gió, bán kính 7 m) | 150 | 25 |
| Thùng gạch tự thu (40 viên, hút 6 m) | 200 | 50 |
| Băng chuyền (dài 6 m) | 120 | 175 |
| Xe đẩy tự động (1 viên / 1,5 s) | 1200 | 1000 |
| Máng trộn bùn (20 kg, tự rót khuôn) | 400 | 300 |


### Lộ trình tiến triển (mục tiêu thiết kế)
| Giai đoạn | Viên | Thời lượng | Trọng tâm |
|---|---|---|---|
| Đầu | 0–175 | ~15 phút | bát → xô, 1–4 khuôn, thổi gió thủ công; mở quạt (25), thùng (50), giá 4 (100) |
| Giữa | 175–2.601 | ~1–1,5 giờ | phễu 20 kg, băng chuyền, máng trộn, giá 8, xe đẩy (1000); Sức mạnh/Tốc độ Lv 10–25 |
| Cuối (marathon) | 2.601–23.426 | nhiều giờ | giá trị gạch tăng 12%/tầng, chuỗi tự động hoá, Sức mạnh 40–60, Tốc độ phi lý |

Quy tắc tăng trưởng: sức mạnh tuyến tính (+0,78 viên/cấp, trần 60); EXP cần ×1,22 mỗi cấp (hàm mũ); tốc độ 6·(1 + 0,10·Δ + 0,004·Δ²) m/s (trần 140).

## 5. Danh mục vật phẩm
- **Công cụ múc**: Bát 600 g · Xô 6,7 kg (mở ở 25 viên) · Phễu 20 kg (mở ở 175).
- **Khuôn**: Khuôn đơn 400 g · Giá 4 · Giá 8 (mỗi ô sấy độc lập, có màu theo độ khô, gạch vàng ánh kim).
- **Sấy & tự động**: Quạt đứng (+40%, bán kính 7 m, hiệu ứng giảm dần 0,7ⁿ khi nhiều quạt) · Thùng gạch tự thu (40 viên, hút 6 m, bốc cả thùng; mang quá sức thì chậm 40%) · Băng chuyền (6 m, 2 m/s, nhận gạch từ khuôn ≤2,5 m) · Máng trộn 20 kg (tự rót khuôn ≤5 m) · Xe đẩy tự động (1 viên/1,5 s, cần ở trong 14 m quanh kim tự tháp).
- **Tiêu hao**: Nắng +20%/+40% (90 s), Bùa mang vác +2, Bùa chạy +25%.
- **Gạch vàng**: 2% mỗi viên sấy xong, thưởng ×50 xu, thông báo toàn phòng, tính vào giải "Nam Châm Gạch Vàng".
- **Bản thiết kế**: đặt bằng búa (🔨) với bóng ma xanh/đỏ, xoay 45°, **di chuyển** công trình đang nhìn, **thu hồi** 50% giá.

## 6. Kiến trúc kỹ thuật thời gian thực

### 6.1 Mô hình mạng (PeerJS/WebRTC, hình sao + lưới voice)
Chủ phòng giữ dữ liệu có thẩm quyền ít nhưng quan trọng; còn lại mô phỏng cục bộ để mượt.

| Tin | Hướng | Tần suất | Nội dung |
|---|---|---|---|
| `pos` | client → host → mọi người | 12 Hz | x,y,z,yaw, số gạch đang vác, đang nói, hoạt động, tiến độ |
| `place` | client → host | khi đặt | số viên + chỉ số gạch vàng; host cộng **tổng chung** |
| `pyr` | host → all | khi đổi | tổng gạch chung + chỉ số vàng ⇒ mọi máy dựng lại đúng N ô đầu |
| `bld` | tới all | khi xây/di chuyển | danh sách công trình (loại,x,z,góc) – chỉ hiển thị |
| `tp` / `tbuy` / `team` | qua host | khi mua | quỹ đội & nâng cấp đội |
| `lb` | host → all | 2 Hz | bảng xếp hạng + hoạt động ("vác gạch lên tầng 4…") |
| `feed`, `emote`, `prank`, `rep` | qua host | sự kiện | nguồn tin cuộc đua, biểu cảm, phá trò, báo cáo |
| `start` / `end` / `results` / `rematch` | host → all | sự kiện | vòng đời trận |

Chống tốn băng thông: **không đồng bộ từng viên gạch** — thứ tự ô cố định nên chỉ cần **một số nguyên N** (+ danh sách chỉ số vàng). Công trình chỉ gửi khi thay đổi; trạng thái khuôn/thùng mô phỏng cục bộ.
Ước tính: 8 người × 12 Hz × ~120 B ≈ 11 KB/s ở chủ phòng — chấp nhận được trên di động.

### 6.2 Voice chat
- Mỗi người mở micro → `GainNode` (tắt tiếng) → `MediaStreamDestination` → gửi `peer.call()` tới từng người (lưới mesh ≤ 8 người; bên có id nhỏ hơn gọi để tránh gọi đôi).
- Đầu nhận: `MediaStreamSource` → **hai nhánh**: `PannerNode` (Gần: suy giảm 3D `inverse`, ref 8 m, tối đa 140 m) và `Gain` trực tiếp (Phòng: cả map). Đổi chế độ chỉ đổi gain hai nhánh (không dựng lại đồ thị ⇒ không giật tiếng).
- Vị trí/hướng `AudioListener` bám camera mỗi khung; vị trí nguồn bám avatar (nội suy) ⇒ giọng nhỏ dần ở bờ sông, to lên gần kim tự tháp.
- HUD: Mic Bật/Tắt/Bấm-để-nói, chế độ Gần/Phòng, vòng sáng quanh avatar đang nói, danh sách người đang nói, **nhắc "Bạn đang tắt mic!"** (đo âm lượng trước khi tắt), tắt tiếng/chặn/báo cáo từng người, **tự tắt mic khi mở menu hoặc ẩn app**, dọn kết nối khi người chơi thoát.
- Hài hước: 5 biểu cảm kèm âm "pop" và chữ nổi trên đầu; tự phát thông báo toàn phòng khi có người bị văng máy chạy.
- Lưu ý: cần HTTPS (Capacitor dùng `https://localhost`), quyền `RECORD_AUDIO` (workflow tự thêm). Chưa cấu hình máy chủ TURN nên một số mạng di động đối xứng có thể không kết nối được voice.

### 6.3 Mô-đun (blueprint để mở rộng)
```
www/js/config.js   dữ liệu & công thức cân bằng (thuần, test được)
www/js/state.js    trạng thái chung G + công thức dẫn xuất (capacity, expMult, sunBonus…)
www/js/bus.js      bus sự kiện (giữ các module không phụ thuộc vòng tròn)
www/js/world.js    cảnh 3D: sa mạc, sông, gym, hub, Pyramid (23.426 ô bằng InstancedMesh), mesh công trình, avatar
www/js/sim.js      mô phỏng: bùn→khuôn→sấy→thùng/băng chuyền/máng/xe đẩy, đặt gạch, kinh tế, gym, xây dựng
www/js/player.js   điều khiển FPS (joystick/WASD), leo bậc, văng máy chạy, tay cầm
www/js/net.js      PeerJS: sảnh, thẩm quyền chủ phòng, bảng xếp hạng, kết quả, rematch
www/js/voice.js    voice chat WebRTC + âm thanh không gian
www/js/ui.js       HUD, bảng Trung tâm, sảnh, bục vinh quang
www/js/main.js     khởi động, vòng lặp
tests/             kiểm thử toán, luồng mô phỏng (mock three), sinh bảng cân bằng
```
Hiệu năng di động: gạch dùng `InstancedMesh` (1 draw call, ≤23.426 thể hiện, cập nhật tăng dần); làn người khác chỉ 26 khối; ô trống phát sáng 24 thể hiện.

## 7. Đã làm vs. chưa làm (trung thực)
**Đã có**: toàn bộ vòng lặp bùn→khuôn→sấy→gạch→đặt; thổi gió (có thanh hơi thở); quạt/nắng; giá 4/8; thùng tự thu; băng chuyền; máng trộn; xe đẩy tự động; gạch vàng; Sức mạnh/Tốc độ có combo & văng máy chạy; kinh tế + mốc + nâng cấp đội/cá nhân; đặt/di chuyển/thu hồi công trình; 2 kiểu đua + tuỳ chỉnh; bảng xếp hạng, nguồn tin, bục vinh quang, giải thưởng, chơi lại; voice chat đủ điều khiển.
**Chưa làm / đơn giản hoá**: xe đẩy gộp vào "xe đẩy tự động"; tương tác "xem gạch vàng" chỉ có hiệu ứng màu + thông báo; báo cáo người chơi chỉ ghi lên nguồn tin; chưa có TURN; mô hình 3D là khối đơn giản; chưa chạy thử trên thiết bị thật (đã kiểm thử logic bằng mock).
