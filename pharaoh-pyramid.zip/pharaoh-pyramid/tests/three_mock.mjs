// Mock tối thiểu của three để kiểm thử logic mô phỏng bằng node (không cần trình duyệt).
// Group/Mesh là lớp thật (có children thật) để các vòng lặp "while children.length" trong mã không bị treo.
const mk = () => new Proxy(function () {}, {
  get: (t, k) => (k === Symbol.toPrimitive ? () => 0 : k === 'then' ? undefined : (k in t ? t[k] : (t[k] = mk()))),
  apply: () => mk(), construct: () => mk(), set: (t, k, v) => { t[k] = v; return true; }
});
const vec = () => ({ x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }, setScalar(s) { this.x = this.y = this.z = s; return this; } });
export class Object3D {
  constructor() { this.children = []; this.position = vec(); this.rotation = vec(); this.scale = vec(); this.userData = {}; this.visible = true; this.parent = null; }
  add(...c) { for (const o of c) { this.children.push(o); o.parent = this; } return this; }
  remove(o) { const i = this.children.indexOf(o); if (i >= 0) this.children.splice(i, 1); return this; }
  clear() { this.children.length = 0; return this; }
  traverse(f) { f(this); this.children.forEach(c => c.traverse && c.traverse(f)); }
}
export class Group extends Object3D {}
export class Mesh extends Object3D { constructor(g, m) { super(); this.geometry = g || mk(); this.material = m || mk(); } }
export class Sprite extends Mesh {}
export class InstancedMesh extends Mesh { constructor(g, m, n) { super(g, m); this.count = n; this.instanceMatrix = mk(); this.instanceColor = null; } setMatrixAt() {} setColorAt() { this.instanceColor = mk(); } }
export const BoxGeometry = mk();
export const CanvasTexture = mk();
export const Color = mk();
export const ConeGeometry = mk();
export const CylinderGeometry = mk();
export const DirectionalLight = mk();
export const DodecahedronGeometry = mk();
export const Euler = mk();
export const Fog = mk();
export const HemisphereLight = mk();
export const Matrix4 = mk();
export const MeshBasicMaterial = mk();
export const MeshStandardMaterial = mk();
export const PerspectiveCamera = mk();
export const PlaneGeometry = mk();
export const Quaternion = mk();
export const RepeatWrapping = 1;
export const SRGBColorSpace = 1;
export const Scene = mk();
export const SphereGeometry = mk();
export const SpriteMaterial = mk();
export const TorusGeometry = mk();
export const Vector3 = mk();
export const WebGLRenderer = mk();
