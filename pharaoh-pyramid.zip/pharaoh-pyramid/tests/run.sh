#!/bin/sh
# Chạy: sh tests/run.sh   (cần node 18+). Sao chép mã sang thư mục tạm, thay 'three' bằng bản giả rồi chạy kiểm thử.
set -e
cd "$(dirname "$0")/.."
node tests/test_config.mjs
T=$(mktemp -d); mkdir -p "$T/js"
for f in www/js/*.js; do sed "s#from 'three'#from '../three_mock.mjs'#" "$f" > "$T/js/$(basename "$f")"; done
cp tests/three_mock.mjs tests/test_flow.mjs "$T/"
cd "$T" && echo "{\"type\":\"module\"}" > package.json && timeout 120 node test_flow.mjs
