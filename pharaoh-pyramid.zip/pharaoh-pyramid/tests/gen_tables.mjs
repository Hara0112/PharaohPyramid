// Sinh bảng cân bằng cho DESIGN.md từ chính config.js:  node tests/gen_tables.mjs
import * as C from '../www/js/config.js';
const out = [];
out.push('### Sức mạnh (tạ)\n\n| Lv | Mang (viên) | Tải (kg) | EXP lên cấp |\n|---|---|---|---|');
for (const l of [1, 2, 5, 10, 12, 20, 30, 40, 50, 60]) out.push(`| ${l} | ${C.strCapacity(l)} | ${C.strWeight(l)} | ${C.expNeed(l).toLocaleString('en')} |`);
out.push('\n### Tốc độ (máy chạy bộ)\n\n| Lv | m/s | km/h | EXP lên cấp |\n|---|---|---|---|');
for (const l of [1, 5, 10, 20, 30, 40, 50, 60, 80]) out.push(`| ${l} | ${C.moveSpeed(l)} | ${(C.moveSpeed(l) * 3.6).toFixed(0)} | ${C.expNeed(l).toLocaleString('en')} |`);
out.push('\n### 26 tầng kim tự tháp\n\n| Tầng | Cạnh | Viên | Cộng dồn | Xu/viên |\n|---|---|---|---|---|');
for (let t = 1; t <= 26; t++) out.push(`| ${t} | ${C.tierSide(t)}×${C.tierSide(t)} | ${C.tierCount(t).toLocaleString('en')} | ${C.TIER_START[t].toLocaleString('en')} | ${C.brickValue(t)} |`);
out.push('\n### Tốc độ sấy & sản lượng lý thuyết mỗi giá khuôn (chưa tính di chuyển)\n\n| Cấu hình | Hệ số sấy | Thời gian sấy | Viên/phút/giá |\n|---|---|---|---|');
const cfgs = [['Khuôn đơn, không hỗ trợ', 0, 0, 1], ['Khuôn đơn + thổi gió', 1, 0, 1], ['Giá 4 + 1 quạt + nắng 20%', 0.4, 0.2, 4], ['Giá 8 + 2 quạt + nắng 60%', 0.4 + 0.28, 0.6, 8], ['Giá 8 + 3 quạt + nắng 60% + EXP/đua x2 sấy', 0.4 + 0.28 + 0.196, 0.6, 8, 2]];
for (const [n, fan, sun, slots, dryx = 1] of cfgs) { const rate = (1 + fan + sun) * dryx, t = C.DRY_BASE / rate; out.push(`| ${n} | x${rate.toFixed(2)} | ${t.toFixed(1)} s | ${(slots * 60 / t).toFixed(1)} |`); }
out.push('\n### Mốc & mở khoá\n\n| Viên | Thưởng | Mở khoá |\n|---|---|---|'); for (const m of C.MILESTONES) out.push(`| ${m.n.toLocaleString('en')} | +${m.coins} xu | ${m.note.replace('Mở khoá: ', '')} |`);
out.push('\n### Giá công trình\n\n| Công trình | Giá (xu) | Mở khoá ở (viên) |\n|---|---|---|'); for (const b of Object.values(C.BUILD)) out.push(`| ${b.name} | ${b.cost} | ${b.unlock} |`);
console.log(out.join('\n'));
