// Kiểm thử luồng mô phỏng (chạy qua tests/run.sh): kinh tế, khuôn sấy, thùng tự thu, băng chuyền, xe đẩy, cột mốc, mua bán, kết thúc ván.
const ctx = new Proxy({}, { get: (t, k) => (k === 'createImageData' ? (w, h) => ({ data: new Uint8ClampedArray(w * h * 4) }) : k === 'createLinearGradient' || k === 'createRadialGradient' ? () => ({ addColorStop() {} }) : () => {}), set: () => true });
globalThis.document = { createElement: () => ({ getContext: () => ctx }) };
globalThis.window = globalThis; globalThis.performance = globalThis.performance || { now: () => Date.now() };
const { G, newPlayer } = await import('./js/state.js');
const C = await import('./js/config.js');
const sim = await import('./js/sim.js');
const { buildWorld } = await import('./js/world.js');
let fail = 0; const ok = (c, m) => { if (!c) { fail++; console.log('FAIL', m); } else console.log('ok  ', m); };

const scene = { add() {}, remove() {} }; G.scene = scene; G.camera = { getWorldDirection() {} };
const W = buildWorld({ add() {}, background: null, fog: null }); G.deposits = W.deposits; G.machines = W.machines; G.hub = W.hub;
G.settings = { race: 'solo', target: 2601, exp: 1, dry: 1, sabotage: false, catchup: false };
sim.resetRace(0, 1); G.phase = 'play';
ok(G.pyr.n === 0 && G.P.coins === 0, 'ván mới trống');

// 1) Đặt gạch + kinh tế + cột mốc
const t0 = G.P.coins; ok(sim.placeBricks(Array(25).fill(false)) === 25 && G.pyr.n === 25, 'đặt 25 viên');
const income = 25 * C.brickValue(1); ok(Math.abs((G.P.coins - t0) - (Math.floor(income * 0.8) + 40)) <= 25, 'thu nhập = giá trị gạch (80%) + thưởng mốc 25');
ok(G.milestone === 1, 'mốc 25 viên đã nhận'); ok(G.team.pool > 0, '20% thu nhập vào quỹ đội');
ok(C.BUILD.crate.unlock <= 50 && G.pyr.n >= C.TOOLS.bucket.unlock, 'xô gỗ đã mở khoá ở 25 viên');

// 2) Mua công cụ / nâng cấp
G.P.coins = 500; sim.buyTool('bucket'); ok(G.P.tool === 'bucket' && G.P.coins === 420, 'mua xô gỗ trừ 80 xu');
G.team.pool = 1000; sim.buyTeam('exp1'); ok(G.team.ups.has('exp1') && G.team.pool === 850, 'nâng cấp đội EXP');
sim.buyTeam('exp3'); ok(!G.team.ups.has('exp3'), 'không mua nhảy cóc nâng cấp');
const { expMult, capacity, sunBonus } = await import('./js/state.js');
ok(Math.abs(expMult() - 1.25) < 1e-9, 'EXP x1,25 sau nâng cấp'); sim.buyConsumable('sun40'); ok(Math.abs(sunBonus() - 0.4) < 1e-9, 'bùa nắng +40%');

// 3) Khuôn + sấy + thùng tự thu
const mold = sim.mkBuilding('rack4', 10, 50, 0), crate = sim.mkBuilding('crate', 12, 50, 0), fan = sim.mkBuilding('fan', 9, 52, 0);
mold.slots.forEach(s => { s.mud = C.MOLD_G; });
for (let i = 0; i < 20 * 60; i++) sim.simUpdate(1 / 60);
ok(crate.items.length === 4 && mold.slots.every(s => !s.done && s.mud === 0), '4 khuôn sấy xong rồi tự vào thùng (nhanh hơn 20 s nhờ nắng + quạt)');

// 4) Băng chuyền -> thùng
const belt = sim.mkBuilding('conveyor', 40, 50, 0), crate2 = sim.mkBuilding('crate', 40 + 3.2 + 2.5, 50, 0), m2 = sim.mkBuilding('mold', 40, 51.5, 0);
m2.slots[0].mud = C.MOLD_G; for (let i = 0; i < 60 * 40; i++) sim.simUpdate(1 / 60);
ok(crate2.items.length === 1 || belt.belt.length === 1, 'băng chuyền chuyển gạch về thùng');

// 5) Xe đẩy tự động đặt gạch (đặt gần kim tự tháp)
const mover = sim.mkBuilding('automover', 30, 0, 0), crate3 = sim.mkBuilding('crate', 32, 0, 0); crate3.items.push(false, false, false);
const before = G.pyr.n; for (let i = 0; i < 60 * 8; i++) sim.simUpdate(1 / 60);
ok(G.pyr.n - before === 3, 'xe đẩy tự động đặt 3 viên (1 viên / 1,5 s)');

// 6) Gạch vàng + tiến độ tầng + kết thúc
const c0 = G.P.coins; sim.placeBricks([true]); ok(G.P.gold === 1 && G.P.coins - c0 >= Math.floor(2 * C.GOLD_MULT * 0.8), 'gạch vàng thưởng x50');
let finished = false; const { on } = await import('./js/bus.js'); on('finish', () => { finished = true; });
sim.placeBricks(Array(3000).fill(false)); ok(G.finished && finished && G.pyr.n === 2601, 'đạt mục tiêu 2.601 thì kết thúc ván, không vượt mục tiêu');

// 7) Tập luyện + văng máy chạy
G.finished = false; G.P = newPlayer(); G.P.spd.lvl = 8; sim.startWorkout(G.machines.find(m => m.kind === 'tread'));
const w = G.P.work; w.next = 10; w.t = 0; sim.workPress(); sim.workPress(); // trượt 2 lần liền ở Lv>=6
ok(G.P.work === null && G.P.wipe > 0 && G.P.wipeouts === 1, 'trượt 2 nhịp liên tiếp thì bị văng khỏi máy chạy bộ');
G.P = newPlayer(); sim.startWorkout(G.machines.find(m => m.kind === 'barbell')); G.P.work.t = 0; const e0 = G.P.str.exp; sim.workPress(); ok(G.P.str.exp > e0 || G.P.str.lvl > 1, 'tập tạ cộng EXP');
console.log(fail ? 'THẤT BẠI ' + fail : 'TẤT CẢ ĐẠT'); process.exit(fail ? 1 : 0);
