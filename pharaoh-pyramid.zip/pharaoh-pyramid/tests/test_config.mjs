import * as C from '../www/js/config.js';
let fail = 0; const ok = (c, m) => { if (!c) { fail++; console.log('FAIL', m); } else console.log('ok  ', m); };
ok(C.TIER_START[26] === 23426, 'tổng 23.426 viên');
ok(C.tierCount(1) === 2601 && C.tierSide(26) === 1, 'tầng đáy 2.601, tầng đỉnh 1 viên');
ok(C.tiersDone(2601) === 1 && C.tiersDone(2600) === 0 && C.tiersDone(23426) === 26, 'tiersDone');
const s0 = C.slotInfo(0), sL = C.slotInfo(23425);
ok(s0.tier === 1 && Math.abs(s0.x + 25) < 1e-9 && Math.abs(s0.z + 25) < 1e-9, 'ô đầu ở góc tầng đáy');
ok(sL.tier === 26 && sL.x === 0 && sL.z === 0, 'ô cuối là đỉnh');
let bad = 0; for (let i = 0; i < 23426; i += 7) { const q = C.slotInfo(i); if (Math.abs(q.x) > 25.5 || Math.abs(q.z) > 25.5 || q.y < 0.25) bad++; }
ok(bad === 0, 'mọi ô nằm trong chân kim tự tháp');
ok(C.pyrFloor(0, 0, 0, 0, 0) === 0, 'chưa xây: mặt đất');
ok(C.pyrFloor(0, 0, 2601, 0, 0) === 0.5, 'xong tầng 1: cao 0,5');
ok(C.pyrFloor(0, 0, 2601 + 10, 0, 0) === 0.5 && C.pyrFloor(0, 0, 2601 + 10, -24, -24) >= 0.5, 'tầng 2 đang xây');
ok(C.pyrFloor(0, 0, 23426, 0, 0) === 13, 'đỉnh cao 13 m');
ok(C.strCapacity(1) === 1 && C.strCapacity(5) === 4 && C.strCapacity(10) === 8 && C.strCapacity(12) === 9, 'sức mang 1→4→8→9');
ok(C.moveSpeed(50) > 90 && C.moveSpeed(200) === 140, 'tốc độ phi lý ở cấp cao');
ok(C.brickValue(1) === 2 && C.brickValue(26) > 30, 'giá trị gạch tăng theo tầng');
console.log(fail ? 'THẤT BẠI ' + fail : 'TẤT CẢ ĐẠT'); process.exit(fail ? 1 : 0);
