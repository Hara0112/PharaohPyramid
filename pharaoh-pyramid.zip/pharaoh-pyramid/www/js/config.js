// ===== Cấu hình & công thức cân bằng (dữ liệu thuần, kiểm thử được bằng node) =====
// Kim tự tháp 26 tầng: cạnh tầng t = 51 - 2(t-1) -> tổng = 26*51*53/3 = 23.426 viên, tầng đáy 51x51 = 2.601 viên.
export const PYR = { tiers: 26, baseSide: 51, total: 23426, ground: 2601, bw: 1, bh: 0.5 };
export const tierSide = t => PYR.baseSide - 2 * (t - 1);
export const tierCount = t => tierSide(t) ** 2;
export const TIER_START = (() => { const a = [0]; for (let t = 1; t <= PYR.tiers; t++) a.push(a[t - 1] + tierCount(t)); return a; })(); // a[t] = số viên của tầng 1..t
export const tiersDone = n => { let t = 0; while (t < PYR.tiers && TIER_START[t + 1] <= n) t++; return t; };
export function tierOfSlot(i) { let t = 1; while (t < PYR.tiers && i >= TIER_START[t]) t++; return t; }
export function slotInfo(i) { // ô thứ i (từ 0): tầng, cột/hàng, toạ độ cục bộ (tâm kim tự tháp = 0,0)
  const t = tierOfSlot(i), s = tierSide(t), k = i - TIER_START[t - 1], row = Math.floor(k / s), col = k % s;
  return { tier: t, side: s, col, row, x: col - s / 2 + 0.5, z: row - s / 2 + 0.5, y: (t - 1) * PYR.bh + PYR.bh / 2 };
}
// Độ cao mặt đứng được tại (x,z) của một kim tự tháp đã xây n viên (để đi lên các bậc)
export function pyrFloor(ox, oz, n, x, z) {
  const td = tiersDone(n), lx = x - ox, lz = z - oz, top = Math.min(PYR.tiers, td + (n < PYR.total ? 1 : 0));
  for (let t = top; t >= 1; t--) {
    const s = tierSide(t), h = s / 2;
    if (Math.abs(lx) > h || Math.abs(lz) > h) continue;
    if (t <= td) return t * PYR.bh;
    const col = Math.min(s - 1, Math.floor(lx + h)), row = Math.min(s - 1, Math.floor(lz + h));
    if (row * s + col < n - TIER_START[td]) return t * PYR.bh;
  }
  return 0;
}

export const brickValue = t => Math.round(2 * Math.pow(1.12, t - 1));      // xu mỗi viên theo tầng
export const TARGETS = { sprint: 300, standard: 2601, marathon: 23426 };    // mục tiêu đua

// ---- Sức mạnh (tạ) và Tốc độ (máy chạy bộ) ----
export const BRICK_KG = 2.5;
export const strCapacity = l => Math.min(60, 1 + Math.floor((l - 1) * 0.78));      // 1 -> 4 (Lv5) -> 8 (Lv10) -> 9 (Lv12) ...
export const strWeight = l => +(strCapacity(l) * BRICK_KG).toFixed(1);               // tải tối đa (kg)
export const expNeed = l => Math.round(30 * Math.pow(1.22, l - 1));
export const moveSpeed = l => Math.min(140, +(6 * (1 + 0.10 * (l - 1) + 0.004 * (l - 1) ** 2)).toFixed(2)); // m/s, tăng phi lý ở cấp cao
export const REP = { perfect: 14, good: 8, miss: 1 };                                 // EXP mỗi lần tập

// ---- Bùn, khuôn, sấy ----
export const MOLD_G = 400, DRY_BASE = 20;            // 400 g/viên, 20 giây sấy cơ bản
export const GOLD_CHANCE = 0.02, GOLD_MULT = 50;     // gạch vàng 2%, thưởng x50
export const POOL_SHARE = 0.2;                       // 20% thu nhập vào quỹ đội
export const DEPOSIT_KG = 6.7, DEPOSIT_REGEN = 0.25; // bãi bùn 6,7 kg, hồi 0,25 kg/s

export const TOOLS = {
  bowl:   { name: 'Bát đất sét', cap: 600, scoop: 600, cost: 0, unlock: 0 },
  bucket: { name: 'Xô gỗ (6,7 kg)', cap: 6700, scoop: 1500, cost: 80, unlock: 25 },
  hopper: { name: 'Phễu lớn (20 kg)', cap: 20000, scoop: 4000, cost: 600, unlock: 175 }
};
export const CATS = { clay: 'Đất sét & Khuôn', auto: 'Vận chuyển & Tự động', work: 'Bệ làm việc' };
export const BUILD = {
  mold:      { cat: 'clay', name: 'Khuôn gạch (400 g)', cost: 30, unlock: 0, slots: 1, r: 0.9 },
  rack4:     { cat: 'clay', name: 'Giá 4 khuôn', cost: 250, unlock: 100, slots: 4, r: 1.6 },
  rack8:     { cat: 'clay', name: 'Giá 8 khuôn', cost: 900, unlock: 500, slots: 8, r: 2.4 },
  fan:       { cat: 'auto', name: 'Quạt sấy (+40% gió, bán kính 7 m)', cost: 150, unlock: 25, wind: 0.4, radius: 7, r: 0.6 },
  crate:     { cat: 'auto', name: 'Thùng gạch tự thu (40 viên, hút 6 m)', cost: 200, unlock: 50, cap: 40, radius: 6, r: 1.0 },
  conveyor:  { cat: 'auto', name: 'Băng chuyền (dài 6 m)', cost: 120, unlock: 175, len: 6, speed: 2, r: 3.2 },
  automover: { cat: 'auto', name: 'Xe đẩy tự động (1 viên / 1,5 s)', cost: 1200, unlock: 1000, rate: 1.5, reach: 14, r: 1.2 },
  mixer:     { cat: 'work', name: 'Máng trộn bùn (20 kg, tự rót khuôn)', cost: 400, unlock: 300, cap: 20000, radius: 5, r: 1.5 }
};
export const slotOffsets = type => ({ mold: [[0, 0]], rack4: [[-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]],
  rack8: [-2.1, -0.7, 0.7, 2.1].flatMap(x => [[x, -0.7], [x, 0.7]]) }[type] || []);

// ---- Nâng cấp đội (mua bằng quỹ đội) ----
export const TEAM_UPS = [
  { id: 'exp1', name: 'EXP +25%', cost: 150, exp: 0.25 }, { id: 'exp2', name: 'EXP +25% (II)', cost: 400, exp: 0.25, req: 'exp1' }, { id: 'exp3', name: 'EXP +25% (III)', cost: 1000, exp: 0.25, req: 'exp2' },
  { id: 'sun1', name: 'Phơi nắng +20%', cost: 200, sun: 0.2 }, { id: 'sun2', name: 'Phơi nắng +20% (II)', cost: 600, sun: 0.2, req: 'sun1' }, { id: 'sun3', name: 'Phơi nắng +20% (III)', cost: 1500, sun: 0.2, req: 'sun2' },
  { id: 'carry1', name: 'Mang vác +1 viên', cost: 250, carry: 1 }, { id: 'carry2', name: 'Mang vác +1 (II)', cost: 700, carry: 1, req: 'carry1' }, { id: 'carry3', name: 'Mang vác +1 (III)', cost: 1800, carry: 1, req: 'carry2' },
  { id: 'move1', name: 'Tốc độ +10%', cost: 180, move: 0.1 }, { id: 'move2', name: 'Tốc độ +10% (II)', cost: 500, move: 0.1, req: 'move1' }
];
// ---- Vật phẩm tiêu hao (mua bằng xu cá nhân) ----
export const CONSUMABLES = [
  { id: 'sun20', name: 'Nắng +20% (90 s)', cost: 60, sun: 0.2, t: 90 }, { id: 'sun40', name: 'Nắng +40% (90 s)', cost: 140, sun: 0.4, t: 90 },
  { id: 'carry', name: 'Bùa mang vác +2 (120 s)', cost: 100, carry: 2, t: 120 }, { id: 'speed', name: 'Bùa chạy +25% (90 s)', cost: 90, move: 0.25, t: 90 }
];
export const MILESTONES = [
  { n: 25, coins: 40, note: 'Mở khoá: Xô gỗ, Quạt sấy' }, { n: 50, coins: 80, note: 'Mở khoá: Thùng gạch tự thu' },
  { n: 100, coins: 120, note: 'Mở khoá: Giá 4 khuôn' }, { n: 175, coins: 160, note: 'Mở khoá: Phễu 20 kg, Băng chuyền' },
  { n: 300, coins: 220, note: 'Mở khoá: Máng trộn bùn' }, { n: 500, coins: 300, note: 'Mở khoá: Giá 8 khuôn' },
  { n: 1000, coins: 500, note: 'Mở khoá: Xe đẩy tự động' }, { n: 2601, coins: 1000, note: 'Hoàn thành TẦNG ĐÁY!' }
];
export const catchBonus = gapFrac => (gapFrac > 0.1 ? 0.25 : gapFrac > 0.05 ? 0.12 : 0); // hỗ trợ người đi sau
