// Âm thanh sinh bằng WebAudio (không cần file) + bộ âm dùng chung cho voice chat
let ac = null;
export function actx() {
  if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
  if (ac.state === 'suspended') ac.resume();
  return ac;
}
const P = { scoop: [220, 120, 0.15, 'sine'], pour: [160, 90, 0.25, 'triangle'], place: [300, 150, 0.1, 'square'], coin: [880, 1320, 0.12, 'sine'],
  perfect: [660, 1320, 0.25, 'sine'], good: [520, 700, 0.15, 'sine'], miss: [200, 90, 0.2, 'sawtooth'], wipeout: [600, 60, 0.9, 'sawtooth'],
  golden: [784, 1568, 0.6, 'triangle'], blow: [300, 280, 0.1, 'sine'], hammer: [180, 80, 0.12, 'square'], level: [440, 880, 0.5, 'triangle'],
  mile: [523, 1047, 0.5, 'triangle'], pop: [700, 500, 0.12, 'sine'], step: [120, 100, 0.06, 'square'], err: [160, 120, 0.15, 'square'], boing: [200, 800, 0.3, 'sine'] };
export function sfx(k, vol = 0.12) {
  try {
    const A = actx(), p = P[k]; if (!p) return;
    const o = A.createOscillator(), g = A.createGain(), t = A.currentTime;
    o.type = p[3]; o.frequency.setValueAtTime(p[0], t); o.frequency.exponentialRampToValueAtTime(Math.max(20, p[1]), t + p[2]);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + p[2]);
    o.connect(g); g.connect(A.destination); o.start(t); o.stop(t + p[2]);
  } catch (e) { /* âm thanh không khả dụng */ }
}
