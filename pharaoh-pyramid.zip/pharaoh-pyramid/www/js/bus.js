// Bus sự kiện nhỏ: các module giao tiếp mà không import vòng tròn
const h = {};
export const on = (e, f) => { (h[e] = h[e] || []).push(f); };
export const emit = (e, ...a) => { (h[e] || []).forEach(f => f(...a)); };
