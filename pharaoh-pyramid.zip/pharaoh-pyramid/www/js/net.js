import { G } from './state.js';
import * as sim from './sim.js';
import { makeAvatar, label } from './world.js';
import { TEAM_UPS, catchBonus } from './config.js';
import { emit } from './bus.js';
import { sfx } from './audio.js';

// ===== Mạng: PeerJS (WebRTC) mô hình sao. Chủ phòng = trọng tài tổng gạch chung / quỹ đội / bảng xếp hạng / kết quả =====
const PREFIX = 'pharaoh-';
export const COLORS = [0x2196f3, 0xe53935, 0x43a047, 0xfdd835, 0x8e24aa, 0xff9800, 0x00acc1, 0xec407a];
const TOHOST = new Set(['place', 'tp', 'tbuy', 'fin', 'stat', 'rep']);   // tin gửi lên chủ phòng (chủ phòng tự xử lý cục bộ)
const RELAY = new Set(['pos', 'bld', 'feed', 'emote', 'prank']);          // chủ phòng chuyển tiếp cho mọi người

export class Net {
  constructor() { this.peer = null; this.conns = new Map(); this.isHost = false; this.hostConn = null; this.id = null; this.acc = { pos: 0, lb: 0 }; this.shared = { total: 0, contrib: {}, gold: [] }; this.statsIn = new Map(); this.ended = false; }
  host(code) {
    return new Promise((res, rej) => {
      this.isHost = true; this.peer = new Peer(PREFIX + code);
      this.peer.on('open', id => { this.id = id; res(id); }); this.peer.on('error', rej);
      this.peer.on('connection', c => {
        c.on('open', () => this.conns.set(c.peer, c)); c.on('data', m => this.hostRecv(m, c.peer, c));
        c.on('close', () => { this.conns.delete(c.peer); this.dropPlayer(c.peer); });
      });
    });
  }
  join(code) {
    return new Promise((res, rej) => {
      const timer = setTimeout(() => rej({ type: 'timeout' }), 10000); this.peer = new Peer();
      this.peer.on('error', e => { clearTimeout(timer); rej(e); });
      this.peer.on('open', id => {
        this.id = id; const c = this.peer.connect(PREFIX + code, { reliable: true }); this.hostConn = c;
        c.on('open', () => { clearTimeout(timer); res(id); }); c.on('data', m => this.clientRecv(m)); c.on('close', () => emit('disconnected'));
      });
    });
  }
  send(m) {
    if (this.isHost) { m.id = m.id || this.id; if (TOHOST.has(m.t)) return this.hostRecv(m, this.id, null); this.bcast(m); }
    else if (this.hostConn && this.hostConn.open) this.hostConn.send(m);
  }
  bcast(m, except) { for (const c of this.conns.values()) if (c !== except && c.open) c.send(m); }
  leave() { try { this.peer && this.peer.destroy(); } catch (e) { /* */ } }

  // ---------- Chủ phòng ----------
  hostRecv(m, from, conn) {
    m.id = from;
    switch (m.t) {
      case 'join': {
        if (G.phase === 'play') return conn && conn.send({ t: 'busy' });
        if (G.players.size >= 8) return conn && conn.send({ t: 'busy' });
        G.players.set(from, { id: from, name: String(m.name || 'Pharaoh').slice(0, 14), color: COLORS[G.players.size % 8], lane: G.players.size });
        this.sendRoster(); break;
      }
      case 'place': {
        if (G.settings.race !== 'shared') break;
        const s = this.shared, base = s.total; s.total += m.k; s.contrib[from] = (s.contrib[from] || 0) + m.k;
        const abs = (m.g || []).map(o => base + o); s.gold.push(...abs);
        const msg = { t: 'pyr', n: s.total, g: abs, c: s.contrib }; this.bcast(msg); if (from !== this.id) sim.setSharedCount(s.total, abs);
        if (s.total >= G.settings.target) this.endRace(from); break;
      }
      case 'tp': if (G.settings.race === 'shared') { G.team.pool += m.amt; this.sendTeam(); } break;
      case 'tbuy': { const u = TEAM_UPS.find(x => x.id === m.id); if (u && !G.team.ups.has(u.id) && (!u.req || G.team.ups.has(u.req)) && G.team.pool >= u.cost) { G.team.pool -= u.cost; G.team.ups.add(u.id); this.sendTeam(); emit('toast', 'Nâng cấp đội: ' + u.name); } break; }
      case 'fin': if (G.settings.race === 'lanes') this.endRace(from); break;
      case 'stat': this.statsIn.set(from, m.s); break;
      case 'rep': { const p = G.players.get(m.who), t = '⚠ ' + (p ? p.name : '?') + ' bị báo cáo'; sim.addFeed(t); this.bcast({ t: 'feed', text: t }); break; }
      default: if (RELAY.has(m.t)) { this.common(m); if (conn) this.bcast(m, conn); }
    }
  }
  sendRoster() { const m = { t: 'roster', players: [...G.players.values()].map(p => ({ id: p.id, name: p.name, color: p.color, lane: p.lane })), settings: G.settings }; this.bcast(m); this.applyRoster(m); }
  sendTeam() { const m = { t: 'team', pool: G.team.pool, ups: [...G.team.ups] }; this.bcast(m); emit('pyr'); }
  setSettings(patch) { Object.assign(G.settings, patch); this.bcast({ t: 'settings', s: G.settings }); emit('roster'); }
  dropPlayer(id) {
    const p = G.players.get(id); if (p && p.avatar) G.scene.remove(p.avatar.group); G.players.delete(id);
    (G.remoteB.get(id) || []).forEach(x => G.scene.remove(x)); G.remoteB.delete(id);
    if (G.voice) G.voice.removeRemote(id);
    [...G.players.values()].forEach((q, i) => { if (G.phase !== 'play') q.lane = i; });
    if (this.isHost) this.sendRoster();
  }
  startRace() {
    if (!this.isHost) return; this.shared = { total: 0, contrib: {}, gold: [] }; this.statsIn.clear(); this.ended = false;
    const roster = [...G.players.values()].map((p, i) => ({ id: p.id, name: p.name, color: p.color, lane: i }));
    this.bcast({ t: 'start', settings: G.settings, roster }); this.beginRace(roster);
  }
  rematch() { if (!this.isHost) return; this.shared = { total: 0, contrib: {}, gold: [] }; this.statsIn.clear(); this.ended = false; this.bcast({ t: 'rematch' }); this.beginRace(G.roster); }
  endRace(winner) { if (this.ended) return; this.ended = true; this.bcast({ t: 'end', winner }); this.onEnd(winner); setTimeout(() => this.computeResults(winner), 2500); }
  computeResults(winner) {
    const rows = [...G.players.values()].map(p => Object.assign({ id: p.id, name: p.name, placed: 0, n: 0, gold: 0, peakStr: 1, peakSpd: 1, wipeouts: 0, riverBuilds: 0, time: 0 }, this.statsIn.get(p.id) || {}));
    const shared = G.settings.race === 'shared';
    rows.sort((a, b) => (shared ? b.placed - a.placed : b.n - a.n || a.time - b.time));
    const awards = [], best = (k, title, unit) => { const r = [...rows].sort((a, b) => b[k] - a[k])[0]; if (r && r[k] > 0) awards.push({ title, name: r.name, v: r[k] + ' ' + unit }); };
    best('wipeouts', '🏃💥 Vua Văng Máy Chạy', 'lần văng'); best('gold', '✨ Nam Châm Gạch Vàng', 'gạch vàng'); best('riverBuilds', '🏗 Kiến Trúc Sư Bờ Sông', 'công trình ven sông'); best('peakStr', '💪 Lực Sĩ Pharaoh', 'Lv sức mạnh');
    const res = { t: 'results', rows, awards, winner, shared, total: shared ? this.shared.total : Math.max(0, ...rows.map(r => r.n)), time: G.raceT, golds: rows.reduce((s, r) => s + r.gold, 0) };
    this.bcast(res); this.showResults(res);
  }
  tick(dt) { // gọi mỗi khung hình
    const P = G.P; if (!P || G.phase !== 'play') return;
    this.acc.pos += dt; if (this.acc.pos >= 1 / 12) {
      this.acc.pos = 0; this.send({ t: 'pos', x: +P.x.toFixed(2), y: +P.y.toFixed(2), z: +P.z.toFixed(2), yaw: +P.yaw.toFixed(2), carry: P.hand.length, spk: !!(G.voice && G.voice.localSpeak),
        act: sim.currentAct(), placed: P.placed, n: G.pyr.n });
    }
    if (this.isHost) { this.acc.lb += dt; if (this.acc.lb >= 0.5) { this.acc.lb = 0; this.buildLb(); } }
  }
  buildLb() {
    const rows = [...G.players.values()].map(p => p.id === G.myId ? { id: p.id, name: p.name, placed: G.P.placed, n: G.pyr.n, act: sim.currentAct() } : { id: p.id, name: p.name, placed: p.placed || 0, n: p.n || 0, act: p.act || 'idle' });
    rows.sort((a, b) => b.placed - a.placed); this.bcast({ t: 'lb', rows }); this.setLb(rows);
  }
  setLb(rows) {
    G.lb = rows; const me = rows.find(r => r.id === G.myId), lead = rows[0];
    G.catchBonus = G.settings.catchup && G.settings.race === 'lanes' && me && lead && lead.id !== me.id ? catchBonus((lead.placed - me.placed) / G.settings.target) : 0; emit('lb');
  }

  // ---------- Người chơi thường ----------
  clientRecv(m) {
    switch (m.t) {
      case 'roster': this.applyRoster(m); break;
      case 'settings': Object.assign(G.settings, m.s); emit('roster'); break;
      case 'start': Object.assign(G.settings, m.settings); this.ended = false; this.beginRace(m.roster); break;
      case 'rematch': this.ended = false; this.beginRace(G.roster); break;
      case 'pyr': sim.setSharedCount(m.n, m.g); G.contrib = m.c; break;
      case 'team': G.team.pool = m.pool; G.team.ups = new Set(m.ups); emit('pyr'); break;
      case 'lb': this.setLb(m.rows); break;
      case 'end': this.onEnd(m.winner); break;
      case 'results': this.showResults(m); break;
      case 'busy': emit('toast', 'Phòng đã đầy hoặc đang chơi'); emit('disconnected'); break;
      default: if (m.t === 'feed' || RELAY.has(m.t)) this.common(m);
    }
  }
  applyRoster(m) {
    Object.assign(G.settings, m.settings); const seen = new Set();
    for (const r of m.players) {
      seen.add(r.id); const old = G.players.get(r.id); const p = old || { id: r.id }; Object.assign(p, { name: r.name, color: r.color, lane: r.lane }); G.players.set(r.id, p);
    }
    for (const id of [...G.players.keys()]) if (!seen.has(id)) { const p = G.players.get(id); if (p && p.avatar) G.scene.remove(p.avatar.group); G.players.delete(id); }
    G.roster = m.players; if (G.voice) G.voice.connectAll(m.players.map(p => p.id)); emit('roster');
  }
  common(m) {
    switch (m.t) {
      case 'pos': { const p = G.players.get(m.id); if (!p || m.id === G.myId) break; ensureAvatar(p); p.tp = { x: m.x, y: m.y, z: m.z }; if (!p.pos) p.pos = { ...p.tp }; p.yaw = m.yaw; p.carry = m.carry; p.spk = m.spk; p.act = m.act; p.placed = m.placed; p.n = m.n; if (G.laneViews.has(m.id)) G.laneViews.get(m.id).setCount(m.n); break; }
      case 'bld': if (m.id !== G.myId) sim.setRemoteBuildings(m.id, m.list); break;
      case 'feed': sim.addFeed(m.text); break;
      case 'emote': showEmote(m.id, m.e); break;
      case 'prank': if (m.to === G.myId) { sim.onPrank(); const f = G.players.get(m.from); sim.addFeed('🟤 ' + (f ? f.name : '?') + ' ném bùn vào bạn!'); } break;
    }
  }
  beginRace(roster) {
    G.roster = roster; const me = roster.find(r => r.id === G.myId) || { lane: 0 };
    for (const r of roster) { const p = G.players.get(r.id) || { id: r.id }; Object.assign(p, { name: r.name, color: r.color, lane: r.lane, placed: 0, n: 0, act: 'idle' }); G.players.set(r.id, p); }
    sim.resetRace(me.lane, roster.length);
    for (const r of roster) if (r.id !== G.myId) { ensureAvatar(G.players.get(r.id)); if (G.settings.race === 'lanes') sim.setLaneView(r.id, r.lane, roster.length); }
    G.phase = 'play'; G.lb = []; emit('start');
  }
  onEnd(winner) {
    G.finished = true; G.winner = winner; emit('finish');
    const P = G.P; setTimeout(() => this.send({ t: 'stat', s: { name: G.name, placed: P.placed, n: G.pyr.n, gold: P.gold, peakStr: P.peakStr, peakSpd: P.peakSpd, wipeouts: P.wipeouts, riverBuilds: P.riverBuilds, time: G.raceT } }), 400);
  }
  showResults(res) { G.results = res; G.phase = 'result'; emit('results'); }
}

export function ensureAvatar(p) {
  if (p.avatar || p.id === G.myId) return; p.avatar = makeAvatar(p.color, p.name); G.scene.add(p.avatar.group); p.pos = p.pos || { x: 0, y: 0, z: 0 }; p.tp = p.tp || { ...p.pos };
}
export function updateAvatars(dt) {
  for (const p of G.players.values()) {
    if (!p.avatar) continue; const k = Math.min(1, dt * 10);
    p.pos.x += (p.tp.x - p.pos.x) * k; p.pos.y += (p.tp.y - p.pos.y) * k; p.pos.z += (p.tp.z - p.pos.z) * k;
    p.avatar.group.position.set(p.pos.x, p.pos.y, p.pos.z); p.avatar.group.rotation.y = p.yaw || 0;
    p.avatar.setCarry(p.carry || 0); p.avatar.setSpeaking(!!(p.spk || (G.voice && G.voice.speaking.get(p.id))));
  }
}
export function showEmote(id, e) {
  sfx('pop', 0.1); const p = G.players.get(id);
  if (id === G.myId || !p || !p.avatar) return emit('toast', e);
  const s = label(e, '#ffffff', true); s.position.y = 3.6; p.avatar.group.add(s); setTimeout(() => p.avatar.group.remove(s), 2200);
}
