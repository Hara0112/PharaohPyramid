import { actx } from './audio.js';
import { G } from './state.js';
import { emit } from './bus.js';

// ===== Voice chat WebRTC (PeerJS media): lưới mesh, 2 chế độ Gần (3D) / Phòng (cả map) =====
// Đường mic -> GainNode (tắt tiếng) -> MediaStreamDestination -> gửi đi: nhờ vậy vẫn đo được "đang nói" khi tắt mic để nhắc nhở.
export class Voice {
  constructor() {
    this.ctx = null; this.out = null; this.gain = null; this.analyser = null; this.silent = null; this.peer = null;
    this.remotes = new Map(); this.calls = new Map(); this.mode = 'prox'; this.state = 'on'; this.ptt = false; this.suspended = false;
    this.speaking = new Map(); this.localSpeak = false; this.mutedTalk = false; this.userMuted = new Set(); this.blocked = new Set(); this.ready = false; this._t = 0;
  }
  async init() {
    try {
      this.ctx = actx();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
      const src = this.ctx.createMediaStreamSource(stream);
      this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 512; src.connect(this.analyser);
      this.gain = this.ctx.createGain(); src.connect(this.gain);
      const dest = this.ctx.createMediaStreamDestination(); this.gain.connect(dest); this.out = dest.stream; this.ready = true; this.apply();
      return true;
    } catch (e) { this.ready = false; emit('toast', 'Không bật được micro (' + (e.name || e) + '). Bạn vẫn nghe được người khác.'); return false; }
  }
  attach(peer) {
    this.peer = peer; this.ctx = this.ctx || actx(); this.silent = this.ctx.createMediaStreamDestination().stream;
    peer.on('call', call => { call.answer(this.out || this.silent); this.hook(call); });
  }
  connectAll(ids) { for (const id of ids) if (id !== G.myId && G.myId < id) this.callPeer(id); } // chỉ phía "nhỏ hơn" gọi để tránh gọi đôi
  callPeer(id) {
    if (!this.peer || this.calls.has(id)) return;
    try { this.hook(this.peer.call(id, this.out || this.silent)); } catch (e) { /* bỏ qua */ }
  }
  hook(call) {
    this.calls.set(call.peer, call);
    call.on('stream', s => this.addRemote(call.peer, s)); call.on('close', () => this.removeRemote(call.peer)); call.on('error', () => this.removeRemote(call.peer));
  }
  addRemote(id, stream) {
    this.removeRemote(id);
    const a = new Audio(); a.srcObject = stream; a.muted = true; a.play().catch(() => {}); // Chrome cần phần tử audio để luồng WebRTC chạy
    const src = this.ctx.createMediaStreamSource(stream), an = this.ctx.createAnalyser(); an.fftSize = 256; src.connect(an);
    const pan = this.ctx.createPanner(); pan.panningModel = 'equalpower'; pan.distanceModel = 'inverse'; pan.refDistance = 8; pan.maxDistance = 140; pan.rolloffFactor = 1.5;
    const gP = this.ctx.createGain(), gR = this.ctx.createGain();
    src.connect(pan); pan.connect(gP); gP.connect(this.ctx.destination); src.connect(gR); gR.connect(this.ctx.destination);
    this.remotes.set(id, { a, src, an, pan, gP, gR, buf: new Uint8Array(an.fftSize) }); this.applyGains(id); emit('voice');
  }
  removeRemote(id) {
    const r = this.remotes.get(id); if (r) { try { r.src.disconnect(); r.a.srcObject = null; } catch (e) { /* */ } this.remotes.delete(id); }
    this.calls.delete(id); this.speaking.delete(id); emit('voice');
  }
  applyGains(id) {
    const r = this.remotes.get(id); if (!r) return; const off = this.userMuted.has(id) || this.blocked.has(id);
    r.gP.gain.value = !off && this.mode === 'prox' ? 1 : 0; r.gR.gain.value = !off && this.mode === 'room' ? 1 : 0;
  }
  apply() { if (!this.gain) return; const open = this.state === 'on' || (this.state === 'ptt' && this.ptt); this.gain.gain.value = open && !this.suspended ? 1 : 0; emit('voice'); }
  setState(s) { this.state = s; this.apply(); }
  setMode(m) { this.mode = m; for (const id of this.remotes.keys()) this.applyGains(id); emit('voice'); }
  setPtt(v) { this.ptt = v; this.apply(); }
  setSuspended(v) { if (this.suspended !== v) { this.suspended = v; this.apply(); } } // tự tắt mic khi mở menu / mất kết nối
  toggleMute(id) { if (this.userMuted.has(id)) this.userMuted.delete(id); else this.userMuted.add(id); this.applyGains(id); emit('voice'); }
  block(id) { this.blocked.add(id); this.applyGains(id); emit('voice'); }
  unblock(id) { this.blocked.delete(id); this.applyGains(id); emit('voice'); }
  report(id) { if (G.net) G.net.send({ t: 'rep', who: id }); emit('toast', 'Đã báo cáo người chơi'); }
  open() { return this.state === 'on' || (this.state === 'ptt' && this.ptt); }
  update(dt) {
    if (!this.ctx) return;
    const l = this.ctx.listener, cam = G.camera; if (cam) {
      const f = [-Math.sin(cam.rotation.y), 0, -Math.cos(cam.rotation.y)];
      if (l.positionX) { l.positionX.value = cam.position.x; l.positionY.value = cam.position.y; l.positionZ.value = cam.position.z; l.forwardX.value = f[0]; l.forwardY.value = 0; l.forwardZ.value = f[2]; l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0; }
      else { l.setPosition(cam.position.x, cam.position.y, cam.position.z); l.setOrientation(f[0], 0, f[2], 0, 1, 0); }
    }
    for (const [id, r] of this.remotes) { const p = G.players.get(id); if (p && p.pos) { if (r.pan.positionX) { r.pan.positionX.value = p.pos.x; r.pan.positionY.value = p.pos.y + 1.7; r.pan.positionZ.value = p.pos.z; } else r.pan.setPosition(p.pos.x, p.pos.y + 1.7, p.pos.z); } }
    this._t += dt; if (this._t < 0.1) return; this._t = 0; let changed = false;
    const rms = (an, buf) => { an.getByteTimeDomainData(buf); let s = 0; for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; s += v * v; } return Math.sqrt(s / buf.length); };
    for (const [id, r] of this.remotes) { const sp = rms(r.an, r.buf) > 0.03; if (this.speaking.get(id) !== sp) { this.speaking.set(id, sp); changed = true; } }
    if (this.analyser) { const b = new Uint8Array(this.analyser.fftSize), sp = rms(this.analyser, b) > 0.04, mt = sp && !this.open(); if (sp !== this.localSpeak || mt !== this.mutedTalk) { this.localSpeak = sp && this.open(); this.mutedTalk = mt; changed = true; } }
    if (changed) emit('voice');
  }
  dispose() { for (const id of [...this.remotes.keys()]) this.removeRemote(id); for (const c of this.calls.values()) { try { c.close(); } catch (e) { /* */ } } this.calls.clear(); }
}
