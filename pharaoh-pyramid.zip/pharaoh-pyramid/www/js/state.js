import { strCapacity, moveSpeed, TEAM_UPS } from './config.js';

// Bố cục thế giới (mét). Hàng kim tự tháp nằm trên trục x (z = 0); sông ở phía nam, phòng gym ở phía bắc.
export const LAYOUT = { hub: { x: 0, z: 46 }, gym: { x: 0, z: -72 }, riverZ: 88, depositZ: 73, laneGap: 80 };
export const laneOrigin = (i, n) => ({ x: (i - (n - 1) / 2) * LAYOUT.laneGap, z: 0 });

export const G = {
  phase: 'menu',                       // menu | lobby | play | result
  settings: { race: 'solo', target: 2601, exp: 1, dry: 1, sabotage: false, catchup: true },
  myId: 'me', name: 'Pharaoh', isHost: true, hostId: 'me', lane: 0, lanes: 1,
  players: new Map(),                  // id -> { id, name, color, lane, n, placed, act, tier, ... }
  net: null, voice: null,
  team: { pool: 0, ups: new Set() },
  pyr: { n: 0, gold: new Set() },      // trạng thái kim tự tháp của mình (hoặc chung)
  origin: { x: 0, z: 0 },              // toạ độ kim tự tháp của mình
  B: [], remoteB: new Map(),           // công trình của mình / của người khác
  feed: [], catchBonus: 0, finished: false, raceT: 0, started: false, milestone: 0,
  P: null, scene: null, camera: null, view: null, laneViews: new Map(),
  uiOpen: false, build: null, blow: false, prompt: null, blowTarget: null,
  lb: [], results: null, deposits: [], machines: [], hub: null
};

export function newPlayer() {
  return { x: 0, y: 0, z: 40, yaw: 0, pitch: 0, vx: 0, vz: 0, vy: 0, ground: true,
    str: { lvl: 1, exp: 0 }, spd: { lvl: 1, exp: 0 }, coins: 0, hand: [], mud: 0, tool: 'bowl', tools: new Set(['bowl']),
    placed: 0, gold: 0, wipeouts: 0, riverBuilds: 0, builds: 0, peakStr: 1, peakSpd: 1, buffs: [], work: null,
    wipe: 0, slow: 0, breath: 100, prankCd: 0, roll: 0 };
}

// ---- Công thức dẫn xuất (dùng chung nhiều module) ----
export const teamSum = k => { let s = 0; for (const u of TEAM_UPS) if (G.team.ups.has(u.id) && u[k]) s += u[k]; return s; };
export const buffSum = k => G.P.buffs.reduce((s, b) => s + (b[k] || 0), 0);
export const capacity = () => strCapacity(G.P.str.lvl) + teamSum('carry') + buffSum('carry');
export const moveSpd = () => moveSpeed(G.P.spd.lvl) * (1 + teamSum('move') + buffSum('move')) * (G.P.slow > 0 ? 0.6 : 1);
export const expMult = () => (1 + teamSum('exp')) * G.settings.exp * (1 + G.catchBonus);
export const sunBonus = () => teamSum('sun') + buffSum('sun');
export const isUnlocked = def => G.pyr.n >= def.unlock;
