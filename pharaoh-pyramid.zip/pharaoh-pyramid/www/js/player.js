import * as THREE from 'three';
import { G, LAYOUT, moveSpd, capacity } from './state.js';
import { pyrFloor, TOOLS } from './config.js';
import { emit } from './bus.js';

// ===== Điều khiển: joystick + vuốt xoay (điện thoại), WASD + chuột (PC) =====
export const input = { move: { x: 0, z: 0 }, use: false, usePressed: false, jump: false, look: { dx: 0, dy: 0 }, keys: {} };
const KEYS = { KeyB: 'build', KeyV: 'mic', Tab: 'lb', KeyT: 'emote', KeyQ: 'prank', Escape: 'menu', KeyR: 'rotate', KeyG: 'recycle', KeyH: 'move' };
export function initControls(canvas) {
  const base = document.getElementById('joy'), knob = document.getElementById('knob'); let pid = null, cx = 0, cy = 0; const R = 55;
  const upd = e => { let dx = e.clientX - cx, dy = e.clientY - cy; const l = Math.hypot(dx, dy); if (l > R) { dx *= R / l; dy *= R / l; } knob.style.transform = `translate(${dx}px,${dy}px)`; input.move.x = dx / R; input.move.z = dy / R; };
  base.addEventListener('pointerdown', e => { pid = e.pointerId; base.setPointerCapture(pid); const r = base.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; upd(e); e.preventDefault(); });
  base.addEventListener('pointermove', e => { if (e.pointerId === pid) upd(e); });
  const end = e => { if (e.pointerId !== pid) return; pid = null; input.move.x = input.move.z = 0; knob.style.transform = ''; };
  base.addEventListener('pointerup', end); base.addEventListener('pointercancel', end);

  // nút giữ: dùng / thổi; nút chạm: nhảy
  const hold = (id, on, off) => { const b = document.getElementById(id); if (!b) return; b.addEventListener('pointerdown', e => { e.preventDefault(); on(); }); for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) b.addEventListener(ev, off); };
  hold('bUse', () => { input.use = true; input.usePressed = true; }, () => { input.use = false; });
  hold('bBlow', () => { G.blow = true; }, () => { G.blow = false; });
  hold('bJump', () => { input.jump = true; }, () => {});
  hold('bPtt', () => emit('key', 'ptt', true), () => emit('key', 'ptt', false));

  addEventListener('keydown', e => {
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    input.keys[e.code] = true;
    if (e.code === 'KeyE' && !e.repeat) { input.use = true; input.usePressed = true; }
    if (e.code === 'KeyF') G.blow = true; if (e.code === 'Space') { input.jump = true; e.preventDefault(); }
    if (e.code === 'KeyC' && !e.repeat) emit('key', 'ptt', true);
    if (KEYS[e.code] && !e.repeat) { emit('key', KEYS[e.code]); e.preventDefault(); }
  });
  addEventListener('keyup', e => { input.keys[e.code] = false; if (e.code === 'KeyE') input.use = false; if (e.code === 'KeyF') G.blow = false; if (e.code === 'KeyC') emit('key', 'ptt', false); });

  // xoay camera: vuốt (cảm ứng) / di chuột (khoá chuột)
  let lid = null, lx = 0, ly = 0;
  canvas.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse') { if (document.pointerLockElement !== canvas && canvas.requestPointerLock) canvas.requestPointerLock(); input.use = true; input.usePressed = true; }
    else if (lid === null) { lid = e.pointerId; lx = e.clientX; ly = e.clientY; canvas.setPointerCapture(e.pointerId); }
  });
  canvas.addEventListener('pointermove', e => {
    if (e.pointerType === 'mouse') { if (document.pointerLockElement === canvas) { input.look.dx += e.movementX * 0.0025; input.look.dy += e.movementY * 0.0025; } }
    else if (e.pointerId === lid) { input.look.dx += (e.clientX - lx) * 0.006; input.look.dy += (e.clientY - ly) * 0.005; lx = e.clientX; ly = e.clientY; }
  });
  const endL = e => { if (e.pointerId === lid) lid = null; if (e.pointerType === 'mouse') input.use = false; };
  canvas.addEventListener('pointerup', endL); canvas.addEventListener('pointercancel', endL);
}

function floorAt(x, z) {
  let f = pyrFloor(G.origin.x, G.origin.z, G.pyr.n, x, z);
  for (const [, v] of G.laneViews) f = Math.max(f, pyrFloor(v.ox, v.oz, v.n, x, z));
  if (Math.abs(x - LAYOUT.gym.x) < 35 && Math.abs(z - LAYOUT.gym.z) < 14) f = Math.max(f, 0.4);
  return f;
}
export const floorHeight = floorAt;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export function updatePlayer(dt) {
  const P = G.P, locked = G.uiOpen;
  if (!locked) { P.yaw -= input.look.dx; P.pitch = clamp(P.pitch - input.look.dy, -1.3, 1.3); }
  input.look.dx = input.look.dy = 0;
  let mx = 0, mz = 0;
  if (!P.work && P.wipe <= 0 && !locked) { const k = input.keys; mx = input.move.x + (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0); mz = input.move.z + (k.KeyS || k.ArrowDown ? 1 : 0) - (k.KeyW || k.ArrowUp ? 1 : 0); const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; } }
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw);
  if (P.wipe > 0) { P.wipe -= dt; P.roll += dt * 9; P.vx *= 1 - 0.8 * dt; P.vz *= 1 - 0.8 * dt; if (P.wipe <= 0) { P.vx = P.vz = 0; P.roll = 0; } }
  else {
    const inRiver = P.z > LAYOUT.riverZ - 9, heavy = P.hand.length > capacity();
    const sp = moveSpd() * (heavy ? 0.6 : 1) * (inRiver ? 0.7 : 1);
    P.vx = (fx * -mz + rx * mx) * sp; P.vz = (fz * -mz + rz * mx) * sp;
  }
  if (input.jump && P.ground && !P.work && P.wipe <= 0 && !locked) P.vy = 8.5; input.jump = false;
  const steps = Math.max(1, Math.ceil((Math.hypot(P.vx, P.vz) * dt) / 0.4)), sdt = dt / steps;
  for (let s = 0; s < steps; s++) {
    const nx = clamp(P.x + P.vx * sdt, -390, 390), nz = clamp(P.z + P.vz * sdt, -110, LAYOUT.riverZ + 9), ok = f => f - P.y <= 0.75;
    if (ok(floorAt(nx, nz))) { P.x = nx; P.z = nz; } else if (ok(floorAt(nx, P.z))) P.x = nx; else if (ok(floorAt(P.x, nz))) P.z = nz;
  }
  const fl = floorAt(P.x, P.z); P.vy -= 24 * dt; P.y += P.vy * dt;
  if (P.y <= fl) { P.y = fl; P.vy = 0; P.ground = true; } else P.ground = P.y - fl < 0.05;
  G.camera.position.set(P.x, P.y + 1.65, P.z); G.camera.rotation.set(P.pitch, P.yaw, P.roll, 'YXZ');
}

// ===== Tay cầm: công cụ múc bùn + chồng gạch (phóng đại hài hước khi mang nhiều) + búa =====
export function makeHands(scene, camera) {
  const g = new THREE.Group(); camera.add(g); scene.add(camera);
  const M = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.8, ...o });
  const toolG = new THREE.Group(), stack = new THREE.Group(), hammer = new THREE.Group(); g.add(toolG, stack, hammer);
  toolG.position.set(0.45, -0.42, -0.8); stack.position.set(-0.42, -0.5, -0.9);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.6, 6), M(0x8d6e63)); shaft.rotation.x = 0.6; hammer.add(shaft);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.14, 0.14), M(0x7a6a58)); head.position.set(0, 0.3, -0.18); hammer.add(head); hammer.position.set(0.4, -0.45, -0.7); hammer.visible = false;
  let curTool = '', curN = -1, swing = 0; const mud = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.02, 12), M(0x4a2f1b));
  return {
    swing() { swing = 1; },
    update(dt) {
      const P = G.P, moving = Math.hypot(P.vx, P.vz) > 0.5;
      if (curTool !== P.tool) { curTool = P.tool; toolG.clear(); const s = P.tool === 'bowl' ? 0.9 : P.tool === 'bucket' ? 1.4 : 2.0; const body = new THREE.Mesh(P.tool === 'bowl' ? new THREE.SphereGeometry(0.2, 12, 8, 0, 6.3, 1.5, 1.6) : new THREE.CylinderGeometry(0.2 * s, 0.15 * s, 0.3 * s, 12, 1, true), M(P.tool === 'hopper' ? 0xa1887f : 0xb08a62, { side: 2 })); toolG.add(body); toolG.add(mud); mud.position.y = 0.05; }
      mud.visible = P.mud > 0; mud.scale.setScalar(0.4 + 0.6 * Math.min(1, P.mud / TOOLS[P.tool].cap));
      if (P.hand.length !== curN) { curN = P.hand.length; stack.clear(); for (let i = 0; i < Math.min(curN, 24); i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.17, 0.34), M(P.hand[i] ? 0xffc400 : 0xd8b070, P.hand[i] ? { emissive: 0x664400 } : {})); b.position.y = i * 0.18; b.rotation.y = (i % 3) * 0.06; stack.add(b); } stack.scale.setScalar(1 + curN * 0.03); }
      const bob = moving ? Math.sin(performance.now() / 120) * 0.02 : 0; g.position.y = bob;
      hammer.visible = !!G.build; if (swing > 0) { swing -= dt * 5; hammer.rotation.x = -Math.sin(swing * 3) * 1.2; } else hammer.rotation.x = 0;
      toolG.visible = !G.build; stack.visible = curN > 0;
    }
  };
}
