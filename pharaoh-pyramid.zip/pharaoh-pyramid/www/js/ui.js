import { G } from './state.js';
import { on, emit } from './bus.js';
import * as sim from './sim.js';
import { PYR, TIER_START, tierOfSlot, brickValue, BUILD, CATS, TOOLS, TEAM_UPS, CONSUMABLES, MILESTONES, strCapacity, strWeight, expNeed, moveSpeed, tiersDone } from './config.js';
import { workMarker } from './sim.js';

export const $ = s => document.querySelector(s);
const ACT = { 'gym-str': '🏋 tập tạ', 'gym-spd': '🏃 chạy bộ', haul: '🧱 vác gạch', mud: '⛏ múc bùn', build: '🔨 xây', idle: '💤' };
const EMOTES = ['😂 Bruh!', '👑 Pharaoh!', '💪 Khỏe chưa!', '🧱 Thêm gạch!', '🎉 Quẩy!'];
const ps = { kind: null, tab: 'team' };
let toastT = 0;

export function showScreen(name) { for (const s of ['menu', 'lobby', 'hud', 'results']) $('#' + s).classList.toggle('hide', s !== name); }
const toast = m => { const t = $('#toast'); t.textContent = m; toastT = 2.4; };

// ================= Panels =================
export function openPanel(kind, tab) { ps.kind = kind; if (tab) ps.tab = tab; G.uiOpen = true; $('#panel').classList.remove('hide'); renderPanel(); }
export function closePanel() { ps.kind = null; G.uiOpen = false; $('#panel').classList.add('hide'); }
const item = (name, sub, btn) => `<div class="it"><div>${name}<small>${sub}</small></div>${btn}</div>`;
function renderPanel() {
  const body = $('#pbody'), tabs = $('#ptabs'), P = G.P; let h = '';
  const T = (id, t) => `<button data-a="tab:${id}" class="${ps.tab === id ? 'on' : ''}">${t}</button>`;
  if (ps.kind === 'hub') {
    tabs.innerHTML = T('team', '🏺 Đội') + T('tools', '🎒 Cá nhân') + T('build', '🔨 Xây dựng');
    if (ps.tab === 'team') {
      h += `<div class="it"><div>Quỹ đội: <b>${Math.floor(G.team.pool)}</b> xu<small>20% mọi thu nhập tự vào quỹ. Nâng cấp ảnh hưởng TOÀN ĐỘI.</small></div><div><button data-a="donate:50">+50</button> <button data-a="donate:200">+200</button></div></div>`;
      for (const u of TEAM_UPS) { const own = G.team.ups.has(u.id), lock = u.req && !G.team.ups.has(u.req); h += item(u.name, own ? 'Đã mua ✔' : lock ? 'Cần nâng cấp trước' : u.cost + ' xu quỹ', own ? '' : `<button data-a="team:${u.id}" ${lock || G.team.pool < u.cost ? 'disabled' : ''}>Mua</button>`); }
    } else if (ps.tab === 'tools') {
      h += `<div class="it"><div>💪 Sức mạnh Lv ${P.str.lvl}<small>Mang tối đa ${strCapacity(P.str.lvl)} viên (${strWeight(P.str.lvl)} kg) • EXP ${Math.floor(P.str.exp)}/${expNeed(P.str.lvl)}</small></div><div>🏃 Lv ${P.spd.lvl}<small>${(moveSpeed(P.spd.lvl) * 3.6).toFixed(0)} km/h</small></div></div>`;
      for (const [id, t] of Object.entries(TOOLS)) { const own = P.tools.has(id), lock = G.pyr.n < t.unlock; h += item(t.name + (P.tool === id ? ' (đang dùng)' : ''), own ? 'Đã sở hữu' : lock ? `Mở khoá ở ${t.unlock} viên` : t.cost + ' xu', `<button data-a="tool:${id}" ${!own && (lock || P.coins < t.cost) ? 'disabled' : ''}>${own ? 'Dùng' : 'Mua'}</button>`); }
      for (const c of CONSUMABLES) h += item(c.name, c.cost + ' xu', `<button data-a="cons:${c.id}" ${P.coins < c.cost ? 'disabled' : ''}>Mua</button>`);
    } else {
      for (const [cat, cn] of Object.entries(CATS)) { h += `<b>${cn}</b>`; for (const [id, b] of Object.entries(BUILD)) if (b.cat === cat) { const lock = G.pyr.n < b.unlock; h += item(b.name, lock ? `Mở khoá ở ${b.unlock} viên` : b.cost + ' xu', `<button data-a="build:${id}" ${lock || P.coins < b.cost ? 'disabled' : ''}>Đặt</button>`); } }
      h += `<div class="it"><div>Công trình đang nhìn</div><div><button data-a="move">Di chuyển</button> <button data-a="recycle">Thu hồi 50%</button></div></div>`;
    }
  } else if (ps.kind === 'lb') {
    tabs.innerHTML = '<b>🏆 Bảng xếp hạng</b>';
    const rows = G.lb.length ? G.lb : [{ id: G.myId, name: G.name, placed: G.P.placed, n: G.pyr.n, act: sim.currentAct() }];
    rows.forEach((r, i) => { const pct = (r.placed / G.settings.target * 100).toFixed(1); h += item(`#${i + 1} ${r.name}${r.id === G.myId ? ' (bạn)' : ''}`, `${ACT[r.act] || ''} • tầng ${tierOfSlot(Math.min(r.n, PYR.total - 1))}`, `<b>${r.placed.toLocaleString()} viên • ${pct}%</b>`); });
    if (G.settings.race === 'shared') h += `<p class="sub">Chế độ chung: xếp hạng theo số gạch mỗi người đóng góp.</p>`;
  } else if (ps.kind === 'voice') {
    tabs.innerHTML = '<b>🎤 Voice chat</b>'; const v = G.voice;
    h += `<div class="it"><div>Micro<small>${v && v.ready ? 'Sẵn sàng' : 'Chưa bật / không có quyền'}</small></div><div><button data-a="mic:on">Bật</button> <button data-a="mic:muted">Tắt</button> <button data-a="mic:ptt">Bấm để nói</button></div></div>`;
    h += `<div class="it"><div>Chế độ<small>Gần: nghe theo khoảng cách 3D • Phòng: nghe cả map</small></div><div><button data-a="vmode:prox">📍 Gần</button> <button data-a="vmode:room">📢 Phòng</button></div></div>`;
    for (const [id, p] of G.players) if (id !== G.myId) h += item(p.name + (v && v.speaking.get(id) ? ' 🟢' : ''), v && v.blocked.has(id) ? 'Đã chặn' : v && v.userMuted.has(id) ? 'Đã tắt tiếng' : 'Đang nghe', `<div><button data-a="vmute:${id}">🔇</button> <button data-a="vblock:${id}">🚫</button> <button data-a="vrep:${id}">⚠</button></div>`);
    if (G.players.size < 2) h += '<p class="sub">Chưa có người chơi khác trong phòng.</p>';
  } else if (ps.kind === 'emote') {
    tabs.innerHTML = '<b>Biểu cảm</b>'; h = EMOTES.map((e, i) => `<button class="big" data-a="emote:${i}">${e}</button>`).join('');
  } else if (ps.kind === 'menu') {
    tabs.innerHTML = '<b>☰ Menu</b>';
    h = `<button class="big" data-a="close">▶ Tiếp tục</button><button class="big" data-a="voicep">🎤 Voice chat</button><button class="big" data-a="leave">🚪 Rời ván</button><p class="sub">Mở menu sẽ tự tắt mic của bạn.</p>`;
  }
  body.innerHTML = h;
}
$('#panel').addEventListener('click', e => {
  const a = e.target.closest('[data-a]'); if (!a) return; const [k, v] = a.dataset.a.split(':'), P = G.P, V = G.voice;
  if (k === 'close') closePanel(); else if (k === 'tab') ps.tab = v; else if (k === 'donate') sim.donate(+v); else if (k === 'team') sim.buyTeam(v);
  else if (k === 'tool') sim.buyTool(v); else if (k === 'cons') sim.buyConsumable(v);
  else if (k === 'build') { closePanel(); sim.startBuild(v); } else if (k === 'move') { closePanel(); sim.moveFront(); } else if (k === 'recycle') sim.recycleFront();
  else if (k === 'mic' && V) V.setState(v); else if (k === 'vmode' && V) V.setMode(v); else if (k === 'vmute' && V) V.toggleMute(v);
  else if (k === 'vblock' && V) V.block(v); else if (k === 'vrep' && V) V.report(v); else if (k === 'voicep') { ps.kind = 'voice'; }
  else if (k === 'emote') { const em = EMOTES[+v]; closePanel(); if (G.net) G.net.send({ t: 'emote', e: em }); emit('emoteLocal', em); }
  else if (k === 'leave') { closePanel(); emit('leaveRace'); return; }
  if (ps.kind) renderPanel();
});

// ================= HUD =================
let acc = 0;
export function frameUI(dt) {
  if (toastT > 0) { toastT -= dt; if (toastT <= 0) $('#toast').textContent = ''; }
  const P = G.P; if (!P || G.phase !== 'play') return;
  const pr = G.prompt; $('#prompt').classList.toggle('hide', !pr); if (pr) $('#prompt').textContent = pr.label;
  $('#bUse b').textContent = pr ? 'DÙNG' : '—';
  const w = P.work; $('#work').classList.toggle('hide', !w);
  if (w) {
    const bar = $('#wkZone'), mk = $('#wkMark');
    if (w.kind === 'barbell') { $('#wkTitle').textContent = '🏋 TẬP TẠ — bấm REP khi vạch trắng vào vùng xanh'; bar.style.left = '44%'; bar.style.width = '12%'; mk.style.left = (workMarker() * 100 - 1) + '%'; $('#bRep').textContent = 'REP!';
      $('#wkInfo').innerHTML = `Sức mạnh Lv ${P.str.lvl} • EXP ${Math.floor(P.str.exp)}/${expNeed(P.str.lvl)}<br>Tải tối đa ${strWeight(P.str.lvl)} kg (${strCapacity(P.str.lvl)} viên) • Combo ${w.combo} <b>${w.last}</b>`; }
    else { $('#wkTitle').textContent = '🏃 MÁY CHẠY — bấm BƯỚC đúng nhịp (vạch chạm cuối thanh)'; bar.style.left = '86%'; bar.style.width = '14%'; mk.style.left = Math.min(98, Math.max(0, (1 - (w.next - w.t) / w.period) * 100)) + '%'; $('#bRep').textContent = 'BƯỚC!';
      $('#wkInfo').innerHTML = `Tốc độ Lv ${P.spd.lvl} • ${w.disp.toFixed(0)} / ${(moveSpeed(P.spd.lvl) * 3.6).toFixed(0)} km/h • Combo ${w.combo} <b>${w.last}</b><br>${P.spd.lvl >= 6 ? '⚠ Trượt 2 lần liên tiếp sẽ bị văng khỏi máy!' : ''}`; }
  }
  $('#splat').classList.toggle('hide', !(P.slow > 0));
  const v = G.voice; $('#mutedWarn').classList.toggle('hide', !(v && v.mutedTalk));
  acc += dt; if (acc < 0.12) return; acc = 0; updateHud();
}
export function updateHud() {
  const P = G.P, n = G.pyr.n, T = G.settings.target, t = tierOfSlot(Math.min(n, PYR.total - 1)), pct = Math.min(100, (n / T) * 100);
  $('#pg').style.width = pct + '%'; $('#pgt').textContent = `🧱 ${n.toLocaleString()} / ${T.toLocaleString()} (${pct.toFixed(1)}%)`;
  const nm = MILESTONES.find(m => m.n > n), tm = Math.floor(G.raceT);
  $('#tinfo').textContent = `Tầng ${t}/${PYR.tiers} • ${brickValue(t)} xu/viên • 🪙 ${Math.floor(P.coins)} • 🏺 ${Math.floor(G.team.pool)}${nm ? ' • mốc ' + nm.n : ''} • ⏱ ${Math.floor(tm / 60)}:${String(tm % 60).padStart(2, '0')}${G.catchBonus ? ' • ⚡ hỗ trợ +' + Math.round(G.catchBonus * 100) + '%' : ''}`;
  const cap = sim.capNow(), tool = TOOLS[P.tool];
  $('#mini').innerHTML = `💪 Lv${P.str.lvl} • 🏃 Lv${P.spd.lvl} (${(moveSpeed(P.spd.lvl) * 3.6).toFixed(0)} km/h)<br>🧱 ${P.hand.length}/${cap} • 🪣 ${(P.mud / 1000).toFixed(1)}/${(tool.cap / 1000).toFixed(1)} kg<br>💨 ${'█'.repeat(Math.round(P.breath / 10))}${'░'.repeat(10 - Math.round(P.breath / 10))}`;
  const rows = G.lb.length ? G.lb : [{ id: G.myId, name: G.name, placed: P.placed, n, act: sim.currentAct() }];
  $('#lbx').innerHTML = rows.slice(0, 4).map((r, i) => `<div class="${r.id === G.myId ? 'me' : ''}"><span>#${i + 1} ${r.name}</span><span>${r.placed} • ${ACT[r.act] || ''}</span></div>`).join('');
  const sp = []; if (G.voice) { if (G.voice.localSpeak) sp.push('Bạn'); for (const [id, v] of G.voice.speaking) if (v) { const p = G.players.get(id); if (p) sp.push(p.name); } }
  $('#spk').textContent = sp.length ? '🔊 ' + sp.join(', ') : '🔈'; const v = G.voice;
  $('#bMic').textContent = !v || !v.ready ? '🚫' : v.state === 'on' ? '🎤' : v.state === 'muted' ? '🔇' : '🎙'; $('#bMode').textContent = v && v.mode === 'room' ? '📢' : '📍';
  $('#bPtt').classList.toggle('hide', !(v && v.state === 'ptt')); $('#bPrank').classList.toggle('hide', !G.settings.sabotage);
}
function feedUI() { $('#feed').innerHTML = G.feed.slice(0, 5).map(f => `<div>${f.text}</div>`).join(''); }

// ================= Lobby / kết quả =================
export function renderLobby() {
  $('#roster').innerHTML = [...G.players.values()].map((p, i) => `<div class="pl"><span>${i === 0 ? '👑 ' : '👤 '}${p.name}${p.id === G.myId ? ' (bạn)' : ''}</span><span style="color:#${p.color.toString(16).padStart(6, '0')}">●</span></div>`).join('');
  const s = G.settings, dis = G.isHost ? '' : 'disabled', op = (v, l, cur) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${l}</option>`;
  const tgt = s.target >= 23426 ? 'marathon' : s.target >= 2601 ? 'standard' : 'sprint';
  $('#lset').innerHTML = `<label>Kiểu đua<select id="sRace" ${dis}>${op('shared', 'Chung 1 kim tự tháp', s.race)}${op('lanes', 'Mỗi người 1 làn', s.race)}</select></label>
    <label>Mục tiêu<select id="sTarget" ${dis}>${op('sprint', 'Nước rút 300', tgt)}${op('standard', 'Tiêu chuẩn 2.601', tgt)}${op('marathon', 'Marathon 23.426', tgt)}</select></label>
    <label>EXP x<select id="sExp" ${dis}>${op(1, '1', s.exp)}${op(2, '2', s.exp)}${op(5, '5', s.exp)}</select></label>
    <label>Sấy khô x<select id="sDry" ${dis}>${op(1, '1', s.dry)}${op(2, '2', s.dry)}${op(5, '5', s.dry)}</select></label>
    <label>Phá trò (ném bùn)<input type="checkbox" id="sSab" ${s.sabotage ? 'checked' : ''} ${dis} style="width:auto"></label>
    <label>Hỗ trợ người đi sau<input type="checkbox" id="sCat" ${s.catchup ? 'checked' : ''} ${dis} style="width:auto"></label>`;
  $('#bStart').classList.toggle('hide', !G.isHost); $('#wait').classList.toggle('hide', G.isHost);
}
function lobbyChange() {
  if (!G.isHost || !G.net) return; const T = { sprint: 300, standard: 2601, marathon: 23426 };
  G.net.setSettings({ race: $('#sRace').value, target: T[$('#sTarget').value], exp: +$('#sExp').value, dry: +$('#sDry').value, sabotage: $('#sSab').checked, catchup: $('#sCat').checked });
}
$('#lset').addEventListener('change', lobbyChange);
export function renderResults() {
  const r = G.results; if (!r) return; showScreen('results'); const medal = ['🥇', '🥈', '🥉'], mm = Math.floor(r.time / 60), ss = Math.floor(r.time % 60);
  const pod = r.rows.slice(0, 3).map((x, i) => `<div style="height:${110 - i * 22}px">${medal[i]}<br><b>${x.name}</b><br>${x.placed} viên</div>`).join('');
  $('#rbox').innerHTML = `<h2>🏁 Bục vinh quang</h2><div class="podium">${pod}</div>
    <div class="aw">⏱ Thời gian xây: <b>${mm}:${String(ss).padStart(2, '0')}</b> • 🧱 Tổng gạch: <b>${r.total.toLocaleString()}</b> • ✨ Gạch vàng: <b>${r.golds}</b></div>
    ${r.rows.map((x, i) => `<div class="pl"><span>#${i + 1} ${x.name}</span><span>💪${x.peakStr} 🏃${x.peakSpd} • ${x.placed} viên • ${x.gold}✨</span></div>`).join('')}
    <h2 style="margin-top:10px">Giải thưởng vui</h2>${r.awards.map(a => `<div class="aw">${a.title}: <b>${a.name}</b> (${a.v})</div>`).join('') || '<div class="aw">Chưa ai nhận giải nào!</div>'}
    ${G.net && !G.isHost ? '<p class="sub">Chờ chủ phòng bấm Chơi lại…</p>' : '<button class="big pri" id="bRematch">🔁 CHƠI LẠI (giữ phòng & voice)</button>'}
    <button class="big" id="bBack">Về menu</button>`;
}

export function initUI() {
  on('toast', toast); on('feed', feedUI); on('roster', renderLobby); on('results', renderResults); on('lb', () => { if (ps.kind === 'lb') renderPanel(); });
  on('openHub', () => openPanel('hub', 'team')); on('pyr', () => { if (ps.kind === 'hub') renderPanel(); });
  on('build', b => { $('#buildbar').classList.toggle('hide', !b); if (!b) emit('hammered'); });
  $('#bbRot').onclick = sim.rotateBuild; $('#bbOk').onclick = sim.confirmBuild; $('#bbNo').onclick = sim.endBuild;
  $('#bRep').onclick = sim.workPress; $('#bExit').onclick = sim.exitWorkout;
  $('#bMenu').onclick = () => openPanel('menu'); $('#bLb').onclick = () => openPanel('lb'); $('#bEmote').onclick = () => openPanel('emote');
  $('#bBuild').onclick = () => { if (G.build) sim.endBuild(); else openPanel('hub', 'build'); }; $('#bPrank').onclick = sim.usePrank;
  const cyc = () => { const v = G.voice; if (!v || !v.ready) return toast('Micro chưa sẵn sàng'); v.setState(v.state === 'on' ? 'muted' : v.state === 'muted' ? 'ptt' : 'on'); };
  $('#bMic').onclick = cyc; $('#lMic').onclick = cyc;
  const mode = () => { const v = G.voice; if (v) v.setMode(v.mode === 'prox' ? 'room' : 'prox'); };
  $('#bMode').onclick = mode; $('#lMode').onclick = () => { mode(); $('#lMode').textContent = G.voice && G.voice.mode === 'room' ? '📢 Phòng' : '📍 Gần'; };
  document.addEventListener('click', e => { if (e.target.id === 'bRematch') emit('rematch'); if (e.target.id === 'bBack') emit('leaveRace'); });
}
export const panelOpenKind = () => ps.kind;
