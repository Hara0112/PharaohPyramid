import * as THREE from 'three';
import { G, LAYOUT, laneOrigin, newPlayer, capacity, expMult, sunBonus, teamSum, isUnlocked } from './state.js';
import { BUILD, TOOLS, TEAM_UPS, CONSUMABLES, MILESTONES, MOLD_G, DRY_BASE, GOLD_CHANCE, GOLD_MULT, POOL_SHARE, DEPOSIT_REGEN, DEPOSIT_KG,
  brickValue, slotInfo, tierOfSlot, TIER_START, PYR, REP, expNeed, moveSpeed } from './config.js';
import { makeBuildingMesh, Pyramid } from './world.js';
import { emit } from './bus.js';
import { sfx } from './audio.js';

const toast = m => emit('toast', m);
export const capNow = () => capacity();
export function addFeed(text) { G.feed.unshift({ text, t: performance.now() }); if (G.feed.length > 6) G.feed.pop(); emit('feed'); }
export function announce(text) { addFeed(text); if (G.net) G.net.send({ t: 'feed', text }); }

// ================= Khởi tạo / đặt lại một ván =================
export function resetRace(lane = 0, lanes = 1) {
  for (const b of G.B) G.scene.remove(b.mesh);
  for (const [, l] of G.remoteB) l.forEach(m => G.scene.remove(m));
  G.remoteB.clear(); G.B = [];
  if (G.view) G.view.dispose(G.scene); for (const [, v] of G.laneViews) v.dispose(G.scene); G.laneViews.clear();
  G.lane = lane; G.lanes = lanes;
  G.origin = G.settings.race === 'lanes' ? laneOrigin(lane, lanes) : { x: 0, z: 0 };
  G.view = new Pyramid(G.scene, G.origin.x, G.origin.z, true);
  G.pyr = { n: 0, gold: new Set() }; G.team = { pool: 0, ups: new Set() };
  G.P = newPlayer(); G.P.x = G.origin.x + (G.settings.race === 'shared' ? (lane - (lanes - 1) / 2) * 3 : 0); G.P.z = 38;
  G.feed = []; G.finished = false; G.milestone = 0; G.catchBonus = 0; G.raceT = 0; G.started = true; G.build = null; G.results = null;
  for (const d of G.deposits) { d.kg = d.max; d.show(); }
  G.view.setCount(0, G.pyr.gold); emit('reset');
}
export function setLaneView(id, lane, lanes) { // kim tự tháp đơn giản của người khác (chế độ làn riêng)
  const o = laneOrigin(lane, lanes); const v = new Pyramid(G.scene, o.x, o.z, false); v.setCount(0); G.laneViews.set(id, v);
}
export const refreshPyramid = () => { if (G.view) G.view.setCount(G.pyr.n, G.pyr.gold); emit('pyr'); };
export function setSharedCount(n, goldIdx) { // host báo tổng gạch chung
  for (const i of goldIdx || []) G.pyr.gold.add(i);
  if (n !== G.pyr.n) { G.pyr.n = n; checkMilestones(); refreshPyramid(); }
}
const slotWorld = i => { if (i >= PYR.total || i >= G.settings.target) return null; const s = slotInfo(i); return { x: s.x + G.origin.x, z: s.z + G.origin.z, y: s.y + 0.25 }; };

// ================= Kinh tế =================
export function addCoins(c) {
  const pool = Math.floor(c * POOL_SHARE); G.P.coins += c - pool;
  if (G.settings.race === 'shared' && G.net) G.net.send({ t: 'tp', amt: pool }); else G.team.pool += pool;
}
function checkMilestones() {
  while (G.milestone < MILESTONES.length && G.pyr.n >= MILESTONES[G.milestone].n) {
    const m = MILESTONES[G.milestone++]; G.P.coins += m.coins; sfx('mile', 0.2);
    toast(`🏆 Mốc ${m.n} viên! +${m.coins} xu — ${m.note}`); announce(`🏆 ${G.name} đạt mốc ${m.n} viên!`);
  }
}
export function placeBricks(flags) {
  if (G.finished || !G.started) return 0;
  let coins = 0, placed = 0; const base = G.pyr.n, golds = [];
  for (const gf of flags) {
    if (G.pyr.n >= G.settings.target || G.pyr.n >= PYR.total) break;
    const i = G.pyr.n, t = tierOfSlot(i); let c = brickValue(t);
    if (gf) { c *= GOLD_MULT; G.pyr.gold.add(i); G.P.gold++; golds.push(i - base); announce(`✨ ${G.name} đặt GẠCH VÀNG! +${c} xu`); sfx('golden', 0.22); emit('golden'); }
    coins += c; G.pyr.n++; G.P.placed++; placed++;
    if (G.pyr.n === TIER_START[t]) { announce(`🏛 ${G.name} hoàn thành tầng ${t}!`); sfx('mile'); }
  }
  if (!placed) return 0;
  addCoins(coins); sfx('place', 0.1); checkMilestones(); refreshPyramid();
  if (G.settings.race === 'shared' && G.net) G.net.send({ t: 'place', k: placed, g: golds });
  if (G.pyr.n >= G.settings.target) finishRace();
  return placed;
}
export function finishRace() { if (G.finished) return; G.finished = true; emit('finish'); }

// ================= Mua bán =================
export function buyTool(id) {
  const t = TOOLS[id]; if (G.P.tools.has(id)) { G.P.tool = id; return toast('Đã trang bị ' + t.name); }
  if (!isUnlocked(t)) return toast('Chưa mở khoá'); if (G.P.coins < t.cost) return toast('Không đủ xu');
  G.P.coins -= t.cost; G.P.tools.add(id); G.P.tool = id; sfx('coin'); toast('Mua ' + t.name);
}
export function buyConsumable(id) {
  const c = CONSUMABLES.find(x => x.id === id); if (G.P.coins < c.cost) return toast('Không đủ xu');
  G.P.coins -= c.cost; G.P.buffs.push({ id, t: c.t, sun: c.sun, carry: c.carry, move: c.move }); sfx('coin'); toast('Dùng ' + c.name);
}
export function buyTeam(id) {
  const u = TEAM_UPS.find(x => x.id === id); if (G.team.ups.has(id)) return;
  if (u.req && !G.team.ups.has(u.req)) return toast('Cần nâng cấp trước đó');
  if (G.settings.race === 'shared' && G.net) return G.net.send({ t: 'tbuy', id });
  if (G.team.pool < u.cost) return toast('Quỹ đội không đủ'); G.team.pool -= u.cost; G.team.ups.add(id); sfx('level'); toast('Nâng cấp: ' + u.name); emit('pyr');
}
export function donate(amt) {
  if (G.P.coins < amt) return toast('Không đủ xu'); G.P.coins -= amt;
  if (G.settings.race === 'shared' && G.net) G.net.send({ t: 'tp', amt }); else G.team.pool += amt; sfx('coin');
}

// ================= Công trình =================
let seq = 1;
export function mkBuilding(type, x, z, rot) {
  const def = BUILD[type], b = { id: 'b' + seq++, type, def, x, z, rot: rot || 0 };
  if (def.slots) b.slots = Array.from({ length: def.slots }, () => ({ mud: 0, prog: 0, done: false, gold: false }));
  if (type === 'crate') b.items = []; if (type === 'mixer') b.kg = 0; if (type === 'conveyor') b.belt = []; if (type === 'automover') b.timer = 0;
  b.mesh = makeBuildingMesh(type); b.mesh.position.set(x, 0, z); b.mesh.rotation.y = b.rot; G.scene.add(b.mesh); G.B.push(b); return b;
}
export function syncBuildings() { if (G.net) G.net.send({ t: 'bld', list: G.B.map(b => [b.type, +b.x.toFixed(1), +b.z.toFixed(1), +b.rot.toFixed(2)]) }); }
export function setRemoteBuildings(id, list) {
  (G.remoteB.get(id) || []).forEach(m => G.scene.remove(m));
  const ms = list.map(([t, x, z, r]) => { const m = makeBuildingMesh(t); m.position.set(x, 0, z); m.rotation.y = r; G.scene.add(m); return m; }); G.remoteB.set(id, ms);
}
const nearOther = (x, z, r, skip) => G.B.some(b => b !== skip && Math.hypot(b.x - x, b.z - z) < b.def.r + r);
const inPyramid = (x, z) => {
  const pyrs = [G.origin, ...[...G.laneViews.values()].map(v => ({ x: v.ox, z: v.oz }))];
  return pyrs.some(o => Math.abs(x - o.x) < 26.5 && Math.abs(z - o.z) < 26.5);
};
export function startBuild(type, moving) {
  const def = BUILD[type];
  if (!moving) { if (!isUnlocked(def)) return toast('Chưa mở khoá'); if (G.P.coins < def.cost) return toast('Không đủ xu'); }
  endBuild();
  const mesh = makeBuildingMesh(type); mesh.traverse(o => { if (o.material) { o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = 0.6; } });
  G.scene.add(mesh); if (moving) moving.mesh.visible = false;
  G.build = { type, rot: moving ? moving.rot : 0, mesh, moving: moving || null, ok: false, x: 0, z: 0 }; emit('build', true);
}
export function endBuild() { const b = G.build; if (!b) return; G.scene.remove(b.mesh); if (b.moving) b.moving.mesh.visible = true; G.build = null; emit('build', false); }
export const rotateBuild = () => { if (G.build) G.build.rot += Math.PI / 4; };
export function confirmBuild() {
  const b = G.build; if (!b || !b.ok) return sfx('err');
  if (b.moving) { b.moving.x = b.x; b.moving.z = b.z; b.moving.rot = b.rot; b.moving.mesh.position.set(b.x, 0, b.z); b.moving.mesh.rotation.y = b.rot; }
  else { G.P.coins -= BUILD[b.type].cost; mkBuilding(b.type, b.x, b.z, b.rot); G.P.builds++; if (b.z > LAYOUT.depositZ - 25) G.P.riverBuilds++; }
  sfx('hammer'); G.scene.remove(b.mesh); const mv = b.moving; G.build = null; if (mv) mv.mesh.visible = true; emit('build', false); syncBuildings();
}
export function frontBuilding(maxD = 6) {
  const P = G.P, fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw); let best = null, bs = 1e9;
  for (const b of G.B) { const dx = b.x - P.x, dz = b.z - P.z, d = Math.hypot(dx, dz); if (d > maxD + b.def.r) continue; const dot = d < 1 ? 1 : (dx * fx + dz * fz) / d; if (dot < 0.4) continue; if (d - dot * 2 < bs) { bs = d - dot * 2; best = b; } }
  return best;
}
export function recycleFront() {
  const b = frontBuilding(); if (!b) return toast('Hãy nhìn vào công trình cần thu hồi');
  G.scene.remove(b.mesh); G.B.splice(G.B.indexOf(b), 1); G.P.coins += Math.floor(b.def.cost / 2); sfx('coin'); toast('Thu hồi: +' + Math.floor(b.def.cost / 2) + ' xu'); syncBuildings();
}
export function moveFront() { const b = frontBuilding(); if (!b) return toast('Hãy nhìn vào công trình cần di chuyển'); startBuild(b.type, b); }
function updateGhost() {
  const b = G.build, P = G.P; if (!b) return;
  const dir = new THREE.Vector3(); G.camera.getWorldDirection(dir);
  const t = Math.min(10, Math.max(2.5, dir.y < -0.05 ? (1.65 + P.y) / -dir.y : 7));
  b.x = Math.round((P.x + dir.x * t) * 2) / 2; b.z = Math.round((P.z + dir.z * t) * 2) / 2;
  const def = BUILD[b.type];
  b.ok = !nearOther(b.x, b.z, def.r, b.moving) && !inPyramid(b.x, b.z) && b.z < LAYOUT.riverZ - 4 && Math.abs(b.x) < 380 && b.z > -100 && !(Math.abs(b.z - LAYOUT.gym.z) < 18 && Math.abs(b.x) < 40);
  b.mesh.position.set(b.x, 0, b.z); b.mesh.rotation.y = b.rot;
  b.mesh.traverse(o => { if (o.material && o.material.color) o.material.emissive && o.material.emissive.setHex(b.ok ? 0x003300 : 0x550000); });
}

// ================= Tương tác theo ngữ cảnh =================
export function computePrompt() {
  const P = G.P; G.prompt = null;
  if (!G.started || G.finished || P.work || P.wipe > 0 || G.build) return;
  const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw); let best = null, bs = 1e9;
  const cand = (x, z, reach, p, bonus = 0) => {
    const dx = x - P.x, dz = z - P.z, d = Math.hypot(dx, dz); if (d > reach) return;
    const dot = d < 1.5 ? 1 : (dx * fx + dz * fz) / d; if (dot < 0.3) return;
    const sc = d - dot * 1.5 + bonus; if (sc < bs) { bs = sc; best = p; }
  };
  for (const m of G.machines) cand(m.x, m.z, 3.8, { label: m.kind === 'barbell' ? '🏋 Tập tạ (Sức mạnh)' : '🏃 Chạy bộ (Tốc độ)', act: () => startWorkout(m) });
  cand(G.hub.x, G.hub.z, 7, { label: '🏺 Mở Trung tâm Nâng cấp', act: () => emit('openHub') });
  const tool = TOOLS[P.tool];
  for (const d of G.deposits) if (P.mud < tool.cap) cand(d.x, d.z, 3.6, { label: `⛏ Múc bùn (${d.kg.toFixed(1)} kg)`, act: () => scoop(d), hold: true });
  for (const b of G.B) {
    const reach = 3 + b.def.r * 0.6;
    if (b.slots) {
      if (P.mud > 0 && b.slots.some(s => s.mud < MOLD_G)) cand(b.x, b.z, reach, { label: '🪣 Đổ bùn vào khuôn', act: () => pour(b), hold: true });
      else if (b.slots.some(s => s.done) && P.hand.length < capacity()) cand(b.x, b.z, reach, { label: '🧱 Lấy gạch', act: () => collect(b), hold: true });
    } else if (b.type === 'crate' && b.items.length) cand(b.x, b.z, reach, { label: `📦 Bốc cả thùng (${b.items.length} gạch)`, act: () => takeCrate(b) });
    else if (b.type === 'mixer' && P.mud > 0) cand(b.x, b.z, reach, { label: '🪣 Đổ bùn vào máng', act: () => pourMixer(b), hold: true });
  }
  if (P.hand.length) { const s = slotWorld(G.pyr.n); if (s && Math.hypot(s.x - P.x, s.z - P.z) < 7 && Math.abs(s.y - P.y) < 3.6) cand(s.x, s.z, 8, { label: `🏛 Đặt gạch (${P.hand.length})`, act: placeOne, hold: true }, -6); }
  G.prompt = best;
}
function scoop(d) {
  const P = G.P, tool = TOOLS[P.tool], amt = Math.min(tool.scoop, tool.cap - P.mud, d.kg * 1000);
  if (amt < 1) { if (d.kg < 0.05) toast('Bãi bùn cạn, chờ hồi'); return; }
  P.mud += amt; d.kg -= amt / 1000; d.show(); sfx('scoop');
}
function pour(b) {
  const P = G.P; let moved = 0;
  for (const s of b.slots) { if (P.mud <= 0) break; const need = MOLD_G - s.mud; if (need <= 0) continue; const give = Math.min(need, P.mud, 800 - moved); if (give <= 0) break; s.mud += give; P.mud -= give; moved += give; }
  if (moved > 0) sfx('pour');
}
function collect(b) {
  const P = G.P; for (const s of b.slots) if (s.done) { P.hand.push(s.gold); if (s.gold) { toast('✨ Gạch vàng!'); sfx('golden'); } else sfx('coin', 0.06); s.mud = 0; s.prog = 0; s.done = false; s.gold = false; return; }
}
function takeCrate(b) { G.P.hand.push(...b.items); b.items = []; sfx('place'); if (G.P.hand.length > capacity()) toast('Nặng quá! Bạn đi chậm lại'); }
function pourMixer(b) { const P = G.P, amt = Math.min(P.mud, b.def.cap - b.kg, 1500); if (amt <= 0) return; P.mud -= amt; b.kg += amt; sfx('pour'); }
function placeOne() { const P = G.P; if (!P.hand.length) return; const g = P.hand.pop(); if (!placeBricks([g])) P.hand.push(g); }
let holdT = 0;
export function useAction(dt, held, pressed) { // gọi mỗi khung hình
  const pr = G.prompt; if (!pr) return;
  if (pressed) { pr.act(); holdT = 0.18; } else if (held && pr.hold) { holdT -= dt; if (holdT <= 0) { pr.act(); holdT = 0.14; } }
}

// ================= Gym: tạ & máy chạy bộ =================
export function startWorkout(m) {
  const P = G.P; if (P.work) return;
  P.x = m.x; P.z = m.z + 2.4; P.yaw = 0; P.pitch = -0.2; P.vx = P.vz = 0;
  const period = Math.max(0.3, 0.7 - 0.008 * P.spd.lvl);
  P.work = m.kind === 'barbell' ? { kind: 'barbell', t: 0, combo: 0, last: '', spd: 1.4 + P.str.lvl * 0.03 }
    : { kind: 'tread', t: 0, combo: 0, miss: 0, period, next: period, disp: 0, last: '' };
  emit('work', true);
}
export const workMarker = () => { const w = G.P.work; return w && w.kind === 'barbell' ? 0.5 + 0.5 * Math.sin(w.t * w.spd * Math.PI) : 0; };
export function exitWorkout() { G.P.work = null; emit('work', false); }
function grade(g, stat) {
  const w = G.P.work; w.combo = g === 'miss' ? 0 : w.combo + 1; w.last = g === 'perfect' ? 'PERFECT!' : g === 'good' ? 'Tốt' : 'Trượt';
  addExp(stat, REP[g] * (1 + w.combo * 0.1) * expMult()); sfx(g === 'perfect' ? 'perfect' : g === 'good' ? 'good' : 'miss');
}
export function workPress() {
  const P = G.P, w = P.work; if (!w) return;
  if (w.kind === 'barbell') { const e = Math.abs(workMarker() - 0.5); grade(e < 0.04 ? 'perfect' : e < 0.13 ? 'good' : 'miss', 'str'); }
  else {
    const err = Math.abs(w.t - w.next), g = err < 0.06 ? 'perfect' : err < 0.16 ? 'good' : 'miss';
    if (g !== 'miss') { w.next += w.period; w.miss = 0; w.disp = Math.min(moveSpeed(P.spd.lvl) * 3.6, w.disp + 3 + w.combo * 0.6); }
    else { w.miss++; if (w.miss >= 2 && P.spd.lvl >= 6) { grade(g, 'spd'); return doWipeout(); } }
    grade(g, 'spd'); sfx('step', 0.05);
  }
}
export function addExp(stat, amt) {
  const s = G.P[stat]; s.exp += amt;
  while (s.exp >= expNeed(s.lvl)) {
    s.exp -= expNeed(s.lvl); s.lvl++; sfx('level'); toast(`⬆ ${stat === 'str' ? 'Sức mạnh' : 'Tốc độ'} Lv ${s.lvl}`);
    if (stat === 'str') G.P.peakStr = Math.max(G.P.peakStr, s.lvl); else G.P.peakSpd = Math.max(G.P.peakSpd, s.lvl);
  }
}
function doWipeout() { // hài hước: văng khỏi máy chạy bộ
  const P = G.P; P.work = null; emit('work', false); P.wipe = 1.8; const a = Math.random() * 6.28;
  P.vx = Math.cos(a) * 18; P.vz = Math.sin(a) * 18 + 8; P.vy = 14; P.wipeouts++; sfx('wipeout', 0.2);
  announce(`💥 ${G.name} bị văng khỏi máy chạy bộ!`); emit('wipeout');
}
export function updateWorkout(dt) {
  const w = G.P.work; if (!w) return; w.t += dt;
  if (w.kind === 'tread') { if (w.t > w.next + 0.3) { w.next += w.period; w.combo = 0; w.disp = Math.max(0, w.disp - 6); } w.disp = Math.max(0, w.disp - dt * 1.5); }
}

// ================= Thổi khô & mô phỏng khuôn / thùng / băng chuyền =================
const fanBonus = b => { const ws = []; for (const f of G.B) if (f.type === 'fan' && Math.hypot(f.x - b.x, f.z - b.z) <= f.def.radius) ws.push(f.def.wind); ws.sort((a, c) => c - a); return ws.reduce((s, w, i) => s + w * Math.pow(0.7, i), 0); };
function updateBlow(dt) {
  const P = G.P; G.blowTarget = null;
  if (G.blow && P.breath > 4 && !P.work && !G.build) {
    const b = frontBuilding(3.2);
    if (b && b.slots && b.slots.some(s => s.mud >= MOLD_G && !s.done)) { G.blowTarget = b; P.breath -= 28 * dt; if (Math.random() < 0.08) sfx('blow', 0.05); return; }
  }
  P.breath = Math.min(100, P.breath + 18 * dt);
}
const _brown = new THREE.Color(0x5a3a22), _tan = new THREE.Color(0xd8b070);
function simBuildings(dt) {
  const sun = sunBonus(), dry = G.settings.dry * (1 + G.catchBonus * 0.5);
  for (const b of G.B) {
    if (b.slots) {
      const rate = (1 + fanBonus(b) + sun + (G.blowTarget === b ? 1 : 0)) * dry;
      b.slots.forEach((s, i) => {
        if (s.mud >= MOLD_G && !s.done) { s.prog += (dt * rate) / DRY_BASE; if (s.prog >= 1) { s.done = true; s.prog = 1; s.gold = Math.random() < GOLD_CHANCE; if (s.gold) announce('✨ Một GẠCH VÀNG vừa xuất hiện ở khuôn của ' + G.name + '!'); } }
        const m = b.mesh.userData.slotMeshes[i]; if (!m) return;
        m.visible = s.mud > 0 || s.done; m.scale.y = s.done ? 1 : 0.15 + 0.85 * (s.mud / MOLD_G); m.position.y = 0.18 + 0.15 * m.scale.y;
        if (s.done) m.material.color.setHex(s.gold ? 0xffc400 : 0xd8b070); else if (s.mud >= MOLD_G) m.material.color.lerpColors(_brown, _tan, s.prog); else m.material.color.copy(_brown);
      });
    } else if (b.type === 'fan') b.mesh.userData.blades.rotation.z += dt * 9;
    else if (b.type === 'mixer') {
      if (b.kg > 0) for (const m of G.B) if (m.slots && Math.hypot(m.x - b.x, m.z - b.z) <= b.def.radius) for (const s of m.slots) if (s.mud < MOLD_G && b.kg > 0) { const g = Math.min(MOLD_G - s.mud, b.kg, 800 * dt); s.mud += g; b.kg -= g; }
      const f = b.mesh.userData.fill; f.scale.y = Math.max(0.01, b.kg / b.def.cap); f.position.y = 0.1 + 0.3 * f.scale.y;
    } else if (b.type === 'crate') {
      if (b.items.length < b.def.cap) for (const m of G.B) if (m.slots && Math.hypot(m.x - b.x, m.z - b.z) <= b.def.radius) for (const s of m.slots) if (s.done && b.items.length < b.def.cap) { b.items.push(s.gold); s.mud = 0; s.prog = 0; s.done = false; s.gold = false; }
      const f = b.mesh.userData.fill; f.scale.y = Math.max(0.01, b.items.length / b.def.cap); f.position.y = 0.15 + 0.4 * f.scale.y;
    } else if (b.type === 'conveyor') updateConveyor(b, dt);
    else if (b.type === 'automover') updateMover(b, dt);
  }
}
function updateConveyor(b, dt) {
  const len = b.def.len, dx = Math.cos(b.rot), dz = -Math.sin(b.rot); // trục dài của băng (mesh xoay quanh y)
  for (const m of G.B) if (m.slots && b.belt.length < 12) for (const s of m.slots) if (s.done) {
    const rx = m.x - b.x, rz = m.z - b.z, along = rx * dx + rz * dz, off = Math.abs(-rx * dz + rz * dx);
    if (off <= 2.5 && Math.abs(along) <= len / 2 + 1) { b.belt.push({ t: Math.min(1, Math.max(0, along / len + 0.5)), gold: s.gold }); s.mud = 0; s.prog = 0; s.done = false; s.gold = false; }
  }
  const ex = b.x + dx * (len / 2), ez = b.z + dz * (len / 2);
  for (let i = b.belt.length - 1; i >= 0; i--) {
    const it = b.belt[i]; it.t = Math.min(1, it.t + (b.def.speed * dt) / len);
    if (it.t >= 1) { const c = G.B.find(k => k.type === 'crate' && k.items.length < k.def.cap && Math.hypot(k.x - ex, k.z - ez) < 3.5); if (c) { c.items.push(it.gold); b.belt.splice(i, 1); } }
  }
  const grp = b.mesh.userData.items; while (grp.children.length < b.belt.length) grp.add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 0.5), new THREE.MeshStandardMaterial({ color: 0xd8b070 })));
  while (grp.children.length > b.belt.length) grp.remove(grp.children[grp.children.length - 1]);
  b.belt.forEach((it, i) => { const c = grp.children[i]; c.position.set((it.t - 0.5) * len, 0.72, 0); c.material.color.setHex(it.gold ? 0xffc400 : 0xd8b070); });
}
function updateMover(b, dt) {
  b.mesh.userData.arm.rotation.y += dt * 2; if (G.finished) return; b.timer += dt;
  const reach = 25.5 + b.def.reach; if (Math.abs(b.x - G.origin.x) > reach || Math.abs(b.z - G.origin.z) > reach) return;
  if (b.timer < b.def.rate) return;
  const c = G.B.find(k => k.type === 'crate' && k.items.length && Math.hypot(k.x - b.x, k.z - b.z) < 3.6); if (!c) return;
  b.timer = 0; const g = c.items.pop(); if (!placeBricks([g])) c.items.push(g);
}

// ================= Cập nhật mỗi khung hình =================
export function currentAct() {
  const P = G.P; if (P.work) return P.work.kind === 'barbell' ? 'gym-str' : 'gym-spd'; if (G.build) return 'build'; if (P.hand.length) return 'haul'; if (P.mud > 0) return 'mud'; return 'idle';
}
export function simUpdate(dt) {
  const P = G.P; if (!G.started) return;
  P.buffs = P.buffs.filter(b => (b.t -= dt) > 0); if (P.slow > 0) P.slow -= dt; if (P.prankCd > 0) P.prankCd -= dt;
  for (const d of G.deposits) if (d.kg < d.max) { d.kg = Math.min(d.max, d.kg + DEPOSIT_REGEN * dt); d.show(); }
  updateWorkout(dt); updateBlow(dt); simBuildings(dt); updateGhost(); computePrompt();
  if (!G.finished) G.raceT += dt;
}
// Phá trò: ném bùn vào đối thủ gần nhất (chỉ khi chủ phòng bật)
export function usePrank() {
  if (!G.settings.sabotage || G.P.prankCd > 0 || !G.net) return toast(G.settings.sabotage ? 'Đang hồi chiêu' : 'Chủ phòng chưa bật phá trò');
  let best = null, bd = 30; for (const [id, p] of G.players) { if (id === G.myId || !p.pos) continue; const d = Math.hypot(p.pos.x - G.P.x, p.pos.z - G.P.z); if (d < bd) { bd = d; best = id; } }
  if (!best) return toast('Không có đối thủ trong 30 m');
  G.P.prankCd = 20; G.net.send({ t: 'prank', to: best, from: G.myId }); sfx('pop'); toast('Ném bùn!');
}
export function onPrank() { G.P.slow = 4; emit('splat'); sfx('boing'); }
