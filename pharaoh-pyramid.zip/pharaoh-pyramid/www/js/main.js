import * as THREE from 'three';
import { G } from './state.js';
import { buildWorld } from './world.js';
import * as sim from './sim.js';
import { initControls, input, updatePlayer, makeHands } from './player.js';
import { Net, updateAvatars, COLORS, showEmote } from './net.js';
import { Voice } from './voice.js';
import { initUI, showScreen, frameUI, openPanel, closePanel, renderLobby, panelOpenKind, $ } from './ui.js';
import { on, emit } from './bus.js';
import { TARGETS } from './config.js';
import { actx } from './audio.js';

// ---------- Three.js ----------
const canvas = $('#c'), renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(75, 1, 0.1, 900);
G.scene = scene; G.camera = camera;
const resize = () => { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); };
addEventListener('resize', resize); resize();
const W = buildWorld(scene); G.deposits = W.deposits; G.machines = W.machines; G.hub = W.hub;
const hands = makeHands(scene, camera);
G.name = 'Pharaoh'; sim.resetRace(0, 1); G.phase = 'menu'; // dựng sẵn cảnh nền cho menu
initControls(canvas); initUI();
addEventListener('pointerdown', () => { try { actx(); } catch (e) { /* */ } }, { once: true });

// ---------- Vào ván ----------
const msg = t => { $('#msg').textContent = t; };
const myName = () => ($('#name').value.trim() || 'Pharaoh').slice(0, 14);
function startSolo() {
  G.name = myName(); G.settings = { race: 'solo', target: TARGETS[$('#soloTarget').value], exp: 1, dry: 1, sabotage: false, catchup: false };
  G.net = null; G.voice = null; G.myId = 'me'; G.isHost = true;
  G.players = new Map([['me', { id: 'me', name: G.name, color: COLORS[0], lane: 0 }]]); G.roster = [{ id: 'me', name: G.name, color: COLORS[0], lane: 0 }];
  sim.resetRace(0, 1); G.phase = 'play'; showScreen('hud'); closePanel(); emit('toast', 'Hãy ra sông múc bùn! (nút DÙNG)');
}
function setupVoice(net) { G.voice = new Voice(); G.voice.attach(net.peer); G.voice.init(); }
async function hostRoom() {
  G.name = myName(); const net = new Net(), code = String(Math.floor(10000 + Math.random() * 90000)); msg('Đang tạo phòng…');
  try { await net.host(code); } catch (e) { return msg('Không tạo được phòng: ' + (e.type || e)); }
  msg(''); G.net = net; G.isHost = true; G.myId = net.id; G.settings = { race: 'shared', target: TARGETS.standard, exp: 1, dry: 1, sabotage: false, catchup: true };
  G.players = new Map([[net.id, { id: net.id, name: G.name, color: COLORS[0], lane: 0 }]]);
  setupVoice(net); $('#rc').textContent = code; G.phase = 'lobby'; showScreen('lobby'); renderLobby();
}
async function joinRoom() {
  G.name = myName(); const code = $('#code').value.trim(); if (!code) return msg('Nhập mã phòng'); const net = new Net(); msg('Đang vào phòng…');
  try { await net.join(code); } catch (e) { return msg('Không vào được phòng: ' + (e.type || e)); }
  msg(''); G.net = net; G.isHost = false; G.myId = net.id; G.players = new Map([[net.id, { id: net.id, name: G.name, color: COLORS[1], lane: 1 }]]);
  net.send({ t: 'join', name: G.name }); setupVoice(net); $('#rc').textContent = code; G.phase = 'lobby'; showScreen('lobby'); renderLobby();
}
$('#bSolo').onclick = startSolo; $('#bHost').onclick = hostRoom; $('#bJoin').onclick = joinRoom;
$('#bStart').onclick = () => G.net && G.net.startRace(); $('#bLeave').onclick = () => location.reload();

on('start', () => { showScreen('hud'); closePanel(); G.phase = 'play'; emit('toast', G.settings.race === 'shared' ? 'Cả đội cùng xây một kim tự tháp!' : 'Mỗi người một làn — ai xong trước thắng!'); });
on('leaveRace', () => { if (G.net) G.net.leave(); if (G.voice) G.voice.dispose(); location.reload(); });
on('disconnected', () => { emit('toast', 'Mất kết nối với chủ phòng'); setTimeout(() => location.reload(), 1500); });
on('rematch', () => { if (G.net) G.net.rematch(); else startSolo(); });
on('emoteLocal', e => showEmote(G.myId, e)); on('hammered', () => hands.swing()); on('build', b => { if (!b) hands.swing(); });
on('wipeout', () => emit('toast', '💥 WIPEOUT!!!'));
on('finish', () => { // kết thúc ván: một mình tự tính kết quả; nhiều người do chủ phòng tính
  emit('toast', '🏁 KIM TỰ THÁP ĐÃ HOÀN THÀNH!');
  if (!G.net) setTimeout(() => {
    const P = G.P, awards = []; if (P.wipeouts) awards.push({ title: '🏃💥 Vua Văng Máy Chạy', name: G.name, v: P.wipeouts + ' lần văng' }); if (P.gold) awards.push({ title: '✨ Nam Châm Gạch Vàng', name: G.name, v: P.gold + ' gạch vàng' }); if (P.riverBuilds) awards.push({ title: '🏗 Kiến Trúc Sư Bờ Sông', name: G.name, v: P.riverBuilds + ' công trình ven sông' });
    G.results = { rows: [{ id: 'me', name: G.name, placed: P.placed, n: G.pyr.n, gold: P.gold, peakStr: P.peakStr, peakSpd: P.peakSpd, wipeouts: P.wipeouts, riverBuilds: P.riverBuilds, time: G.raceT }], awards, winner: 'me', shared: false, total: G.pyr.n, time: G.raceT, golds: P.gold };
    G.phase = 'result'; emit('results');
  }, 1500);
});
on('key', (k, v) => {
  if (G.phase !== 'play') return;
  if (k === 'ptt') { if (G.voice) G.voice.setPtt(!!v); return; }
  if (k === 'menu') return panelOpenKind() ? closePanel() : openPanel('menu');
  if (k === 'lb') return panelOpenKind() === 'lb' ? closePanel() : openPanel('lb');
  if (k === 'emote') return openPanel('emote');
  if (k === 'build') return G.build ? sim.endBuild() : openPanel('hub', 'build');
  if (k === 'prank') return sim.usePrank();
  if (k === 'rotate') return sim.rotateBuild(); if (k === 'recycle') return sim.recycleFront(); if (k === 'move') return sim.moveFront();
  if (k === 'mic' && G.voice && G.voice.ready) G.voice.setState(G.voice.state === 'on' ? 'muted' : 'on');
});

// ---------- Vòng lặp ----------
let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000); last = now; W.update(dt);
  if (G.phase === 'play') {
    updatePlayer(dt); sim.simUpdate(dt);
    if (!G.uiOpen) {
      if (G.P.work) { if (input.usePressed) sim.workPress(); }
      else if (G.build) { if (input.usePressed) sim.confirmBuild(); }
      else sim.useAction(dt, input.use, input.usePressed);
    }
    input.usePressed = false;
    if (G.net) G.net.tick(dt);
  } else if (G.phase !== 'result') { const t = now / 7000; camera.position.set(Math.cos(t) * 78, 30, Math.sin(t) * 78); camera.lookAt(0, 6, 0); }
  updateAvatars(dt);
  if (G.voice) { G.voice.update(dt); G.voice.setSuspended(G.uiOpen || document.hidden); } // tự tắt mic khi mở menu / ẩn app
  if (G.view) G.view.pulse(now / 1000);
  hands.update(dt); frameUI(dt); renderer.render(scene, camera);
}
requestAnimationFrame(loop);
