import * as THREE from 'three';
import { PYR, TIER_START, slotInfo, tierSide, tiersDone, BUILD, slotOffsets, DEPOSIT_KG } from './config.js';
import { LAYOUT } from './state.js';

const mat = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, ...o });

export function label(text, color = '#ffffff', big = false) { // nhãn chữ bay (sprite)
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const g = c.getContext('2d'); g.font = 'bold ' + (big ? 38 : 30) + 'px sans-serif'; g.textAlign = 'center'; g.lineWidth = 6; g.strokeStyle = '#000'; g.fillStyle = color;
  g.strokeText(text, 128, 42); g.fillText(text, 128, 42);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
  s.scale.set(4, 1, 1); s.renderOrder = 10; return s;
}
function noiseTex(base, dots, rep, size = 256) {
  const c = document.createElement('canvas'); c.width = c.height = size; const g = c.getContext('2d');
  g.fillStyle = base; g.fillRect(0, 0, size, size);
  for (let i = 0; i < 1800; i++) { g.fillStyle = dots[i % dots.length]; g.globalAlpha = 0.35; g.fillRect(Math.random() * size, Math.random() * size, 2, 2); }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep, rep); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function buildWorld(scene) {
  scene.background = new THREE.Color(0x8fd0f5);
  scene.fog = new THREE.Fog(0xe9d8b4, 90, 480);
  scene.add(new THREE.HemisphereLight(0xcfe8ff, 0xc8a56a, 1.1));
  const sun = new THREE.DirectionalLight(0xfff0c8, 1.7); sun.position.set(120, 200, 80); scene.add(sun);
  const W = { deposits: [], machines: [], hub: LAYOUT.hub, update: () => {} };

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(1600, 1600), mat(0xffffff, { map: noiseTex('#d9b56f', ['#e6c88a', '#c49a55', '#b88a45'], 200), roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; scene.add(ground);
  for (let i = 0; i < 26; i++) { // cồn cát xa
    const a = (i / 26) * Math.PI * 2, r = 480 + Math.random() * 120, d = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), mat(0xc9a35f));
    d.scale.set(70 + Math.random() * 70, 18 + Math.random() * 30, 60 + Math.random() * 60); d.position.set(Math.cos(a) * r, -2, Math.sin(a) * r); scene.add(d);
  }

  // sông + bờ bùn
  const wt = noiseTex('#2f9fd8', ['#58c0ee', '#1f7fb8'], 30, 128);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(1200, 26), mat(0xffffff, { map: wt, roughness: 0.2, transparent: true, opacity: 0.88 }));
  water.rotation.x = -Math.PI / 2; water.position.set(0, 0.05, LAYOUT.riverZ + 4); scene.add(water);
  const bank = new THREE.Mesh(new THREE.PlaneGeometry(1200, 18), mat(0x6a4a2c, { map: noiseTex('#6a4a2c', ['#5a3c22', '#7a5636'], 120) }));
  bank.rotation.x = -Math.PI / 2; bank.position.set(0, 0.03, LAYOUT.riverZ - 18); scene.add(bank);
  W.update = dt => { wt.offset.x += dt * 0.02; };

  // bãi bùn (6,7 kg), hồi dần
  for (let x = -150; x <= 150; x += 30) {
    const g = new THREE.Group(), mound = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.7, 0.7, 14), mat(0x5a3a22));
    mound.position.y = 0.35; g.add(mound); g.position.set(x, 0, LAYOUT.depositZ); scene.add(g);
    const d = { x, z: LAYOUT.depositZ, kg: DEPOSIT_KG, max: DEPOSIT_KG, mesh: g, mound };
    d.show = () => { d.mound.scale.y = 0.25 + 0.75 * (d.kg / d.max); };
    W.deposits.push(d);
  }

  // cọ, đá, cột cổ
  const palmN = 70, trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.25, 0.35, 7, 6), mat(0x7a5a34), palmN);
  const crowns = new THREE.InstancedMesh(new THREE.SphereGeometry(2.2, 8, 6), mat(0x3f8a3c), palmN), m4 = new THREE.Matrix4();
  for (let i = 0; i < palmN; i++) {
    const x = (Math.random() * 2 - 1) * 330, z = LAYOUT.riverZ - 30 + Math.random() * 12 - (Math.random() < 0.4 ? 150 : 0);
    m4.makeTranslation(x, 3.5, z); trunks.setMatrixAt(i, m4);
    m4.compose(new THREE.Vector3(x, 7.2, z), new THREE.Quaternion(), new THREE.Vector3(1, 0.45, 1)); crowns.setMatrixAt(i, m4);
  }
  scene.add(trunks, crowns);
  const rocks = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), mat(0x9a8468), 70);
  for (let i = 0; i < 70; i++) {
    const s = 0.8 + Math.random() * 2.4;
    m4.compose(new THREE.Vector3((Math.random() * 2 - 1) * 360, s * 0.4, -130 + Math.random() * 250), new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.random(), Math.random(), 0)), new THREE.Vector3(s, s * 0.7, s));
    rocks.setMatrixAt(i, m4);
  }
  scene.add(rocks);
  for (let i = 0; i < 18; i++) { // cột đá cổ
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.1, 9, 10), mat(0xcdb98e)); const x = -300 + i * 36 + Math.random() * 10, z = -120 - Math.random() * 40;
    p.position.set(x, 4.5, z); scene.add(p);
  }

  // Trung tâm Nâng cấp (Blueprint & Upgrade Hub): tháp obelisk phát sáng
  const hub = new THREE.Group(), ob = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 1.6, 9, 4), mat(0xd8c18a));
  ob.position.y = 4.5; hub.add(ob);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.8, 1.6, 4), mat(0xffd54f, { emissive: 0xffa000, emissiveIntensity: 1.2 })); tip.position.y = 9.8; hub.add(tip);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(4, 0.12, 8, 32), mat(0xffd54f, { emissive: 0xffa000, emissiveIntensity: 0.9 })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.2; hub.add(ring);
  for (const dx of [-5, 5]) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.5, 0.4), mat(0x8a6a3c)); t.position.set(dx, 1.75, 2); hub.add(t); }
  const cloth = new THREE.Mesh(new THREE.BoxGeometry(10.6, 0.15, 5), mat(0xb3342b)); cloth.position.set(0, 3.5, 2); hub.add(cloth);
  const lb = label('TRUNG TÂM NÂNG CẤP', '#ffd54f', true); lb.position.y = 12; lb.scale.set(7, 1.7, 1); hub.add(lb);
  hub.position.set(LAYOUT.hub.x, 0, LAYOUT.hub.z); scene.add(hub);

  // Phòng gym ngoài trời: tạ + máy chạy bộ
  const gym = new THREE.Group();
  const plat = new THREE.Mesh(new THREE.BoxGeometry(70, 0.4, 28), mat(0xbfae8a)); plat.position.y = 0.2; gym.add(plat);
  const gl = label('DESERT GYM', '#ff8a65', true); gl.position.set(0, 7, 0); gl.scale.set(9, 2.2, 1); gym.add(gl);
  gym.position.set(LAYOUT.gym.x, 0, LAYOUT.gym.z); scene.add(gym);
  for (let i = 0; i < 3; i++) { // 3 giá tạ
    const g = new THREE.Group(), base = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.2, 1.8), mat(0x5d4037)); base.position.y = 0.5; g.add(base);
    for (const sx of [-1.2, 1.2]) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.6, 0.15), mat(0x8d6e63)); post.position.set(sx, 1.3, 0); g.add(post); }
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8), mat(0xb0b0b8, { metalness: 0.7 })); bar.rotation.z = Math.PI / 2; bar.position.y = 1.9; g.add(bar);
    for (const sx of [-1.4, -1.2, 1.2, 1.4]) { const pl = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.12, 14), mat(0x303038)); pl.rotation.z = Math.PI / 2; pl.position.set(sx, 1.9, 0); g.add(pl); }
    const x = LAYOUT.gym.x - 24 + i * 8, z = LAYOUT.gym.z; g.position.set(x, 0.4, z); scene.add(g);
    W.machines.push({ kind: 'barbell', x, z, mesh: g });
  }
  for (let i = 0; i < 3; i++) { // 3 máy chạy bộ
    const g = new THREE.Group(), base = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.35, 3.4), mat(0x37474f)); base.position.y = 0.55; g.add(base);
    const belt = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.06, 3.0), mat(0x111111)); belt.position.y = 0.76; g.add(belt);
    for (const sx of [-0.65, 0.65]) { const r = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.3, 0.08), mat(0xb0bec5)); r.position.set(sx, 1.35, -1.3); g.add(r); }
    const disp = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.5, 0.15), mat(0x222222, { emissive: 0x00e676, emissiveIntensity: 0.8 })); disp.position.set(0, 2.0, -1.4); g.add(disp);
    const x = LAYOUT.gym.x + 8 + i * 8, z = LAYOUT.gym.z; g.position.set(x, 0.4, z); scene.add(g);
    W.machines.push({ kind: 'tread', x, z, mesh: g });
  }
  return W;
}

// ===== Kim tự tháp: bản đầy đủ (instancing 23.426 viên) hoặc bản đơn giản (tầng khối) cho làn của người khác =====
export class Pyramid {
  constructor(scene, ox, oz, full) {
    this.ox = ox; this.oz = oz; this.n = 0; this.full = full; this.group = new THREE.Group(); this.group.position.set(ox, 0, oz); scene.add(this.group);
    this.sandMat = mat(0xd9b56f);
    if (full) {
      this.im = new THREE.InstancedMesh(new THREE.BoxGeometry(0.98, 0.48, 0.98), mat(0xffffff), PYR.total); this.im.count = 0; this.im.frustumCulled = false; this.group.add(this.im);
      this.ghost = new THREE.InstancedMesh(new THREE.BoxGeometry(0.96, 0.46, 0.96), new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0.45 }), 24); this.ghost.count = 0; this.ghost.frustumCulled = false; this.group.add(this.ghost);
    } else {
      this.tiers = [];
      for (let t = 1; t <= PYR.tiers; t++) { const m = new THREE.Mesh(new THREE.BoxGeometry(tierSide(t), PYR.bh, tierSide(t)), this.sandMat); m.position.y = (t - 0.5) * PYR.bh; m.visible = false; this.group.add(m); this.tiers.push(m); }
    }
  }
  setCount(n, gold) {
    if (this.full) {
      const m = new THREE.Matrix4(), c = new THREE.Color();
      if (n < this.n) this.n = 0;
      for (let i = this.n; i < n; i++) {
        const s = slotInfo(i); m.makeTranslation(s.x, s.y, s.z); this.im.setMatrixAt(i, m);
        if (gold && gold.has(i)) c.setHex(0xffc400); else c.setHSL(0.11, 0.42 + ((i * 7) % 10) * 0.01, 0.5 + s.tier * 0.011 + ((i * 13) % 7) * 0.004);
        this.im.setColorAt(i, c);
      }
      this.im.count = n; this.im.instanceMatrix.needsUpdate = true; if (this.im.instanceColor) this.im.instanceColor.needsUpdate = true;
      const k = Math.min(24, PYR.total - n); this.ghost.count = k; // ô trống sáng phía trước
      for (let j = 0; j < k; j++) { const s = slotInfo(n + j); m.makeTranslation(s.x, s.y, s.z); this.ghost.setMatrixAt(j, m); }
      this.ghost.instanceMatrix.needsUpdate = true;
    } else {
      const td = tiersDone(n), part = n - TIER_START[td];
      this.tiers.forEach((m, i) => {
        const t = i + 1; m.visible = t <= td || (t === td + 1 && part > 0);
        const f = t <= td ? 1 : Math.max(0.05, part / (tierSide(t) ** 2)); m.scale.y = f; m.position.y = (t - 1) * PYR.bh + (PYR.bh * f) / 2;
      });
    }
    this.n = n;
  }
  pulse(t) { if (this.ghost) this.ghost.material.opacity = 0.3 + 0.2 * Math.sin(t * 4); }
  dispose(scene) { scene.remove(this.group); }
}

// ===== Công trình người chơi đặt =====
export function makeBuildingMesh(type) {
  const g = new THREE.Group(), wood = mat(0x8d6e63), dark = mat(0x5d4037);
  g.userData.slotMeshes = [];
  if (BUILD[type].slots) {
    const offs = slotOffsets(type), w = type === 'mold' ? 1.4 : type === 'rack4' ? 2.8 : 5.6, d = type === 'mold' ? 1.4 : 2.8;
    const base = new THREE.Mesh(new THREE.BoxGeometry(w, 0.18, d), wood); base.position.y = 0.09; g.add(base);
    for (const [ox, oz] of offs) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.3, 0.95), mat(0x5a3a22)); s.position.set(ox, 0.3, oz); g.add(s); g.userData.slotMeshes.push(s); }
  } else if (type === 'fan') {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 0.2, 10), dark); base.position.y = 0.1; g.add(base);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2, 8), wood); pole.position.y = 1.1; g.add(pole);
    const blades = new THREE.Group(); blades.position.set(0, 2.2, 0.1);
    for (let i = 0; i < 4; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.9, 0.04), mat(0xefe3b8)); b.position.y = 0.45; const h = new THREE.Group(); h.rotation.z = (i * Math.PI) / 2; h.add(b); blades.add(h); }
    g.add(blades); g.userData.blades = blades;
  } else if (type === 'crate') {
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.15, 1.8), wood); base.position.y = 0.08; g.add(base);
    for (const [x, z, sx, sz] of [[0, -0.85, 1.8, 0.1], [0, 0.85, 1.8, 0.1], [-0.85, 0, 0.1, 1.8], [0.85, 0, 0.1, 1.8]]) { const w = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.9, sz), wood); w.position.set(x, 0.55, z); g.add(w); }
    const fill = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 1.5), mat(0xd8b070)); fill.position.y = 0.2; fill.scale.y = 0.01; g.add(fill); g.userData.fill = fill;
  } else if (type === 'conveyor') {
    const len = BUILD.conveyor.len, belt = new THREE.Mesh(new THREE.BoxGeometry(len, 0.2, 1.0), mat(0x222222)); belt.position.y = 0.5; g.add(belt);
    for (const z of [-0.55, 0.55]) { const r = new THREE.Mesh(new THREE.BoxGeometry(len, 0.3, 0.08), wood); r.position.set(0, 0.55, z); g.add(r); }
    for (const x of [-len / 2 + 0.3, len / 2 - 0.3]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.5, 1.1), dark); l.position.set(x, 0.25, 0); g.add(l); }
    g.userData.items = new THREE.Group(); g.add(g.userData.items);
  } else if (type === 'mixer') {
    const tr = new THREE.Mesh(new THREE.BoxGeometry(3, 0.8, 1.6), wood); tr.position.y = 0.4; g.add(tr);
    const fill = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.7, 1.3), mat(0x4a2f1b)); fill.position.y = 0.45; fill.scale.y = 0.01; g.add(fill); g.userData.fill = fill;
    for (const x of [-1.3, 1.3]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.2, 0.2), dark); p.position.set(x, 0.6, 0.9); g.add(p); }
  } else if (type === 'automover') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.6, 1.4), wood); body.position.y = 0.7; g.add(body);
    for (const [x, z] of [[-0.8, 0.8], [0.8, 0.8], [-0.8, -0.8], [0.8, -0.8]]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.15, 12), dark); w.rotation.x = Math.PI / 2; w.position.set(x, 0.35, z); g.add(w); }
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.15, 0.2), mat(0xffd54f)); arm.position.set(0, 1.3, 0); g.add(arm); g.userData.arm = arm;
  }
  return g;
}

// ===== Nhân vật Pharaoh (người chơi khác) =====
export function makeAvatar(color, name) {
  const g = new THREE.Group(), skin = mat(0xe0b080), gold = mat(0xffc107, { metalness: 0.5 });
  const legs = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.4), mat(0xf5f0e0)); legs.position.y = 0.4; g.add(legs);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.7, 0.4), skin); torso.position.y = 1.15; g.add(torso);
  const collar = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.18, 0.5), gold); collar.position.y = 1.45; g.add(collar);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), skin); head.position.y = 1.78; g.add(head);
  const nemes = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.5, 0.62), mat(color)); nemes.position.set(0, 1.9, -0.05); g.add(nemes);
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.08, 0.64), gold); stripe.position.set(0, 1.98, -0.05); g.add(stripe);
  const tag = label(name, '#ffffff'); tag.position.y = 2.7; g.add(tag);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.05, 6, 20), new THREE.MeshBasicMaterial({ color: 0x69f0ae })); ring.rotation.x = Math.PI / 2; ring.position.y = 2.35; ring.visible = false; g.add(ring);
  const stack = new THREE.Group(); stack.position.set(0, 1.0, -0.55); g.add(stack);
  let carry = -1;
  return {
    group: g, ring,
    setCarry(n) { if (n === carry) return; carry = n; stack.clear(); for (let i = 0; i < Math.min(n, 20); i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 0.5), mat(0xd8b070)); b.position.y = i * 0.27; stack.add(b); } stack.scale.setScalar(1 + n * 0.015); },
    setSpeaking(v) { ring.visible = v; }
  };
}
