# 👑 Pharaoh's Pyramid

Game hài hước góc nhìn thứ nhất (Three.js + PeerJS + Capacitor → **APK Android**): xây kim tự tháp 26 tầng / 23.426 viên từ bùn, tập gym, tự động hóa, đua cùng bạn bè có voice chat.
Chi tiết thiết kế, bảng cân bằng, kiến trúc mạng & voice: xem [DESIGN.md](DESIGN.md).

## Đưa lên GitHub và build APK (chỉ cần điện thoại)
1. Trên GitHub tạo repo mới (ví dụ `PharaohPyramid`), để trống.
2. **Add file → Upload files** → chọn `pharaoh-pyramid.zip` → Commit. *(GitHub không tự giải nén zip; workflow bên dưới sẽ giải nén.)*
3. **Add file → Create new file**, đặt tên đúng `.github/workflows/build-apk.yml`, dán toàn bộ nội dung file `build-apk.yml` (đi kèm) → Commit.
4. Vào tab **Actions → Build APK** (tự chạy sau commit, hoặc bấm *Run workflow*). Đợi khoảng 6–10 phút.
5. Vào **Releases → "Pharaoh's Pyramid – APK mới nhất"** (hoặc artifact `PharaohsPyramid-apk`), tải `app-debug.apk` và cài (bật *Cài từ nguồn không rõ*). Lần đầu mở, cho phép quyền **micro** để dùng voice chat.

Workflow tự chạy kiểm thử logic trước khi build; nếu kiểm thử lỗi, build dừng lại.

## Cách chơi
- **Điện thoại**: joystick trái; vuốt bên phải để nhìn; nút **DÙNG** (giữ để lặp) cho mọi hành động theo ngữ cảnh; **💨 Thổi** làm khuôn khô nhanh; **Nhảy**; **🔨** mở Bản thiết kế / thoát chế độ xây; ☰ menu; 🏆 xếp hạng; 😂 biểu cảm; 🎤 mic; 📍/📢 voice Gần/Phòng.
- **PC**: WASD, chuột (bấm để khoá), E dùng, F thổi, Space nhảy, B xây, V mic, C bấm-để-nói, T biểu cảm, Tab xếp hạng, Esc menu, R xoay, G thu hồi, H di chuyển công trình.
- Vòng đầu: ra bãi bùn (⛏ múc) → đổ vào khuôn (đặt khuôn bằng 🔨) → thổi cho khô → lấy gạch → vác lên kim tự tháp, đặt vào ô sáng. Ghé **Desert Gym** để tăng sức mang và tốc độ; ghé **Trung tâm Nâng cấp** (obelisk) để nâng cấp đội và mua công cụ.

## Chạy thử trên máy tính
```
npm install
npm start          # mở www/ bằng serve
npm test           # kiểm thử toán + luồng mô phỏng (cần node 18+)
node tests/gen_tables.mjs   # in lại bảng cân bằng
```
